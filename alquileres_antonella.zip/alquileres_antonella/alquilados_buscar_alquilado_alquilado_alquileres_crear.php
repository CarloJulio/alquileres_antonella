<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["alquiler_crear_s_error"])){
        $_SESSION["alquiler_crear_s_error"] = "No";
    }
    if (!isset($_SESSION["alquiler_crear_error_mensaje"])){
        $_SESSION["alquiler_crear_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["alquiler_crear_s_guardar"])){
        $_SESSION["alquiler_crear_s_guardar"] = "No";
    }
    if (!isset($_SESSION["alquiler_id_bien_crear"])){
        $_SESSION["alquiler_id_bien_crear"] = "";
    }
    if (!isset($_SESSION["alquiler_descripcion_crear"])){
        $_SESSION["alquiler_descripcion_crear"] = "";
    }
    if (!isset($_SESSION["alquiler_monto_crear"])){
        $_SESSION["alquiler_monto_crear"] = "";
    }
    if (!isset($_SESSION["alquiler_fecha_crear"])){
        $_SESSION["alquiler_fecha_crear"] = "";
        // Hora y fecha actual
        $sql = "SELECT current_date";
        $row = $mysqli->query($sql);
        $consultaf = $row->fetch_assoc();
        $fechadelmysql = date_create($consultaf['current_date']);
        $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
        $_SESSION['fecha_hoy'] = $fechadelmysql;
        $_SESSION["alquiler_fecha_crear"] = $_SESSION['fecha_hoy'];
        // Pasar fecha a formato de - a /
        $fecha_bien = $_SESSION["alquiler_fecha_crear"];
        $fecha_bien = trim($fecha_bien);
        $fecha_bien_li_valores = explode('-', $fecha_bien);
        $fecha_bien_1i = "$fecha_bien_li_valores[0]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[2]";
        $_SESSION["alquiler_fecha_crear"] = $fecha_bien_1i;
    }
    // Bienes 
    $sqlsu = "SELECT id_bien, bien, descripcion FROM tab_bienes ORDER BY bien";
    $querysu = $mysqli->query($sqlsu);
    $combobit3="<option value='0'>Seleccionar</option>";
    while ($rowsu=$querysu->fetch_assoc()) { 
        if($rowsu['id_bien'] == $_SESSION["alquiler_id_bien_crear"]){
            $combobit3.=" <option value='".$rowsu['id_bien']."' selected='selected'>".$rowsu['bien']." - ".$rowsu['descripcion']."</option>"; 
        }else{
            $combobit3.=" <option value='".$rowsu['id_bien']."'>".$rowsu['bien']." - ".$rowsu['descripcion']."</option>"; 
        }
    }
    // Datos del Alquilado
    $id_alquilado = $_SESSION["id_alquilado"];
    $alquilado_nro_identidad = $_SESSION["alquilado_nro_identidad"];
    $alquilado_nombre = $_SESSION["alquilado_nombre"];
    $alquilado_apellido = $_SESSION["alquilado_apellido"];
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquileres - Crear</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Alquileres - Crear</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=<?php echo $id_alquilado ?>">Volver</a>
      <br/><br/>
      <font class="font2">Id Alquilado: <?php echo $id_alquilado; ?></font><br/>
      <font class="font2">Nro. Identidad: <?php echo $alquilado_nro_identidad; ?></font><br/>
      <font class="font2">Nombre: <?php echo $alquilado_nombre; ?></font><br/>
      <font class="font2">Apellido: <?php echo $alquilado_apellido; ?></font><br/>
      <br/><br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Crear Alquiler</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
		<div style="overflow-x:auto"> 
		<form name="formulario_alquiler" method="POST" action="alquilados_buscar_alquilado_alquilado_alquileres_crear_validar_1.php" onsubmit="validar_formulario_alquiler();return document.MM_returnValue">
            <table class="tab6" align="center">	
                <tr>   
                <td>   
                    <label><b>Bien</b></label>
                    <select class="input" name="alquiler_id_bien_crear" ><?php echo $combobit3;?></select>
                </td>
                </tr>
                <tr>   
                <td>    
                    <label><b>Descripción</b></label>
                    <input class="input" type="text" name="alquiler_descripcion_crear" maxlength="255" value="<?php echo $_SESSION["alquiler_descripcion_crear"] ?>">
                </td>
                </tr>
                <tr>   
                <td>     
                    <label><b>Fecha</b></label>
                    <input class="input" type="text" name="alquiler_fecha_crear" id="datepicker" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION["alquiler_fecha_crear"] ?>"/>
                </td>
                </tr>
                <tr>   
                <td>    
                    <label><b>Monto</b></label>
                    <input class="input" type="text" name="alquiler_monto_crear" maxlength="15" value="<?php echo $_SESSION["alquiler_monto_crear"] ?>">
                </td>
                </tr>
                <tr>   
                <tr>   
                <td>    
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        <br/>
        </div> <!-- <div style="overflow-x:auto"> -->	
	  </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["alquiler_crear_s_error"];
        $error_mensaje = $_SESSION["alquiler_crear_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["alquiler_crear_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $usuario_crear_s_guardar = $_SESSION["alquiler_crear_s_guardar"];
    if($usuario_crear_s_guardar == "Si") {
        $_SESSION["alquiler_crear_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "alquilados_buscar_alquilado_alquilado_alquileres_crear_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario alquiler con javascript
    function validar_formulario_alquiler() { 
        var errors="";
        var valor_seleccionar = document.forms['formulario_alquiler'].elements['alquiler_id_bien_crear'].value;
        if (errors == "" && valor_seleccionar == "0") {
            errors += '<font style="color:red">Debes Seleccionar el Bien</font>';
        } 
        var valor_vacio = document.forms['formulario_alquiler'].elements['alquiler_descripcion_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Descripción no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_alquiler'].elements['alquiler_monto_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Monto no debe estar vacio</font>';
        } 
        var monto = document.forms['formulario_alquiler'].elements['alquiler_monto_crear'].value;
        // Chequea si el monto es un número
        if(errors == "" && isNaN(monto)) {
            errors += '<font style="color:red">El Monto debe ser un número</font>';    
        }
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>