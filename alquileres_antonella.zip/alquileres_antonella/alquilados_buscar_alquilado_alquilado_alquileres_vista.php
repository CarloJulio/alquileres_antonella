<?php
  // Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de bien esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Datos de alquiler  
	$id_alquiler = $_GET["id_alquiler"];
  $id_alquilado = $_SESSION["id_alquilado"];
  // Buscar datos del bien
  $sql = "SELECT id_alquiler, id_bien, descripcion, fecha_alquiler_reg, monto ";
  $sql .= "FROM tab_alquileres WHERE (id_alquiler = ".$id_alquiler.")";
  $query = $mysqli->query($sql);
  $nro_registros = $query->num_rows;
  $row = $query->fetch_assoc();
  // Si existe el alquiler
  if($nro_registros != 0) {
    // Datos del alquiler
    $id_alquiler = $row['id_alquiler'];
    $id_bien = $row['id_bien'];
    // Datos del bien
    $sql2 = "SELECT id_bien, bien, descripcion ";
    $sql2 .= "FROM tab_bienes WHERE (id_bien = ".$id_bien.")";
    $query2 = $mysqli->query($sql2);
    $nro_registros2 = $query2->num_rows;
    $row2 = $query2->fetch_assoc();
    // Si existe el bien
    if($nro_registros2 != 0) {
      $bien = $row2['bien']." - ".$row2['descripcion'];
    } else {
      $bien = "???";
    } 
    $descripcion = $row['descripcion'];
    $fecha = $row['fecha_alquiler_reg'];
    $monto = $row['monto'];
    // Pasar fecha a formato español
    $fecha_bien = $row['fecha_alquiler_reg'];
    $fecha_bien = trim($fecha_bien);
    $fecha_bien_li_valores = explode('-', $fecha_bien);
    $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
    $fecha = $fecha_bien_1i;
  } else {
    echo "Alquiler no encontrado";
    exit;
  }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
  <!-- Caracteres en español -->
	<meta charset="UTF-8">
  <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquileres - Vista</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	  <!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <script>
      function printe(){
        //desaparece el boton
        document.getElementById("menu").style.display='none';
        document.getElementById("volver").style.display='none';
        document.getElementById("Imprimir").style.display='none';
        //se imprime la pagina
        window.print();
        //reaparece el boton
        document.getElementById("menu").style.display='inline';
        document.getElementById("volver").style.display='inline';
        document.getElementById("Imprimir").style.display='inline';
      }
    </script>
</head>
<body>
	<div class="contenedor">
        <!-- Datos de bien -->
        <font class="font6"><b>Alquiler</b></font>
        <br/><br/>
        <font class="font6">Id Alquiler: <?php echo $id_alquiler ?></font>
        <br/>
        <font class="font6">Bien: <?php echo $bien ?></font>
        <br/>
        <font class="font6">Descripción: <?php echo $descripcion ?></font>
        <br/>
        <font class="font6">Fecha: <?php echo $fecha ?></font>
        <br/>
        <font class="font6">Monto: <?php echo $monto ?></font>
        <br/><br/>
        <font class="font6">
        <span class="empresa">
        <?php 
          // mini Sistemas cjcv
          require("mini.php"); 
        ?>
        </span>
        </font>
        <br/>
        <br/>
        <!-- Enlaces -->
		    <a id="menu" href="menu.php"><font class="font7">Menú</font></a>&nbsp&nbsp
        <a id="volver" href="alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=<?php echo $id_alquilado ?>">Volver</a>&nbsp&nbsp
        <a id="Imprimir" href="#" onclick="printe()"><font class="font7">Imprimir</font></a> 
        <br/><br/>
	  </div> <!-- class="contenedor card texto-centrado" -->	 
  </div> <!-- class="contenedor" -->
</body>
</html> 