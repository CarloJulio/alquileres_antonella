<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    } 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Validar formulario bucar alquilado con php
	$id_alquilado = $_SESSION["alquilados_buscar_alquilado_editar_id_alquilado"];
	$alquilado_actual_nro_identidad = $_SESSION["alquilados_buscar_alquilado_editar_actual_nro_identidad"];
	if (isset($_POST["alquilados_buscar_alquilado_editar_nro_identidad"])) {
		$_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"] = trim($_POST["alquilados_buscar_alquilado_editar_nro_identidad"]);
		$_SESSION["alquilados_buscar_alquilado_editar_nombre"] = $_POST["alquilados_buscar_alquilado_editar_nombre"];
		$_SESSION["alquilados_buscar_alquilado_editar_apellido"] = $_POST["alquilados_buscar_alquilado_editar_apellido"];
		$alquilado_nro_identidad = trim($_POST["alquilados_buscar_alquilado_editar_nro_identidad"]);
		// Si el Alquilado ya existe
		if ($alquilado_actual_nro_identidad != $alquilado_nro_identidad) {
			$sql_alquilado = "SELECT nro_identidad FROM tab_alquilados WHERE (nro_identidad = $alquilado_nro_identidad)";
			$query_alquilado = $mysqli->query($sql_alquilado);
			$row_alquilado = $query_alquilado->fetch_assoc();
			$nro_registros_alquilado = $query_alquilado->num_rows;
			if($nro_registros_alquilado != 0) {
   				$_SESSION["alquilados_buscar_alquilado_editar_s_error"] = "Si";
				$_SESSION["alquilados_buscar_alquilado_editar_error_mensaje"] = "El Nro. de Identidad del Alquilado ya existe";
				echo "<script>location.href = 'alquilados_buscar_alquilado_editar.php?id_alquilado=$id_alquilado'</script>";
				exit();	
			} 
		} // if ($alquilado_actual_nro_identidad != $alquilado_nro_identidad)
		// Validación formulario alquilado correcto
		$_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "Si";
		echo "<script>location.href = 'alquilados_buscar_alquilado_editar.php?id_alquilado=$id_alquilado'</script>";
	} // if (isset($_POST["alquilados_buscar_alquilado_editar_nro_identidad"]))
?>