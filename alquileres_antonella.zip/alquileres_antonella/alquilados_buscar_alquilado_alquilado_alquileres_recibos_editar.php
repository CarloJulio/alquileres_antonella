<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["alquiler_editar_s_error"])){
        $_SESSION["alquiler_editar_s_error"] = "No";
    }
    if (!isset($_SESSION["alquiler_editar_error_mensaje"])){
        $_SESSION["alquiler_editar_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["recibo_editar_s_guardar"])){
        $_SESSION["recibo_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["recibo_descripcion_editar"])){
        $_SESSION["recibo_descripcion_editar"] = "";
    }
    if (!isset($_SESSION["recibo_fecha_editar"])){
        $_SESSION["recibo_fecha_editar"] = "";
    }
    if (!isset($_SESSION["recibo_monto_editar"])){
        $_SESSION["recibo_monto_editar"] = "";
    }
    if (!isset($_SESSION["recibo_usuario_editar"])){
        $_SESSION["recibo_usuario_editar"] = "";
    }
    // El alquiler seleccionado para editar
    if (isset($_GET["id_recibo"])) {
        $id_recibo = $_GET["id_recibo"];  
        $_SESSION["id_recibo_editar_recibos"] = $_GET["id_recibo"];  
        $sql_recibo = "SELECT id_recibo, descripcion, fecha_recibo_reg, monto, usuario FROM tab_recibos WHERE (id_recibo = $id_recibo)";
        $query_recibo = $mysqli->query($sql_recibo);
        $row_recibo = $query_recibo->fetch_assoc();
        $nro_registros_recibo = $query_recibo->num_rows;
        if($nro_registros_recibo != 0) {
            $descripcion = $row_recibo['descripcion'];
            $fecha = $row_recibo['fecha_recibo_reg'];
            $monto = $row_recibo['monto'];
            $usuario = $row_recibo['usuario'];
            // Pasar fecha a formato español
            $fecha_bien = $fecha;
            $fecha_bien = trim($fecha_bien);
            $fecha_bien_li_valores = explode('-', $fecha_bien);
            $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
            // Iniciar variables de sesiones
            if(empty($_SESSION["recibo_descripcion_editar"])) {
                $_SESSION["recibo_descripcion_editar"] = $descripcion;
            }
            if(empty($_SESSION["recibo_fecha_editar"])) {
                $_SESSION["recibo_fecha_editar"] = $fecha_bien_1i;
            }
            if(empty($_SESSION["recibo_monto_editar"])) {
                $_SESSION["recibo_monto_editar"] = $monto;
            }
            $_SESSION["recibo_usuario_editar"] = $usuario;
        } else {
            echo "No se encuentra el Recibo";
            exit();
        }
    } // if (isset($_GET["id_alquiler"]))
    // Datos del Alquiler
    $id_alquiler = $_SESSION["id_alquiler"];
    $bien = $_SESSION["bien"];
    $alquiler_descripcion = $_SESSION["alquiler_descripcion"];
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Recibos - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Recibos - Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=<?php echo $id_alquiler ?>">Volver</a>
      <br/><br/>
      <font class="font2">Id Alquiler: <?php echo $id_alquiler; ?></font><br/>
      <font class="font2">Bien: <?php echo $bien; ?></font><br/>
      <font class="font2">Descripción: <?php echo $alquiler_descripcion; ?></font><br/>
      <font class="font2">Id Recibo: <?php echo $id_recibo; ?></font><br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Editar Recibo</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
        <div style="overflow-x:auto"> 
		<form name="formulario_recibo" method="POST" action="alquilados_buscar_alquilado_alquilado_alquileres_recibos_editar_validar_1.php" onsubmit="validar_formulario_recibo();return document.MM_returnValue">
            <table class="tab6" align="center">	
                <tr>   
                <td> 
                    <label><b>Descripción</b></label>
                    <input class="input" type="text" name="recibo_descripcion_editar" maxlength="255" value="<?php echo $_SESSION["recibo_descripcion_editar"] ?>">
                </td>
                </tr>
                <tr>   
                <td>  
                    <label><b>Fecha</b></label>
                    <input class="input" type="text" name="recibo_fecha_editar" id="datepicker" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION["recibo_fecha_editar"] ?>"/>
                </td>
                </tr>
                <tr>   
                <td>    
                    <label><b>Monto</b></label>
                    <input class="input" type="text" name="recibo_monto_editar" maxlength="15" value="<?php echo $_SESSION["recibo_monto_editar"] ?>">
                </td>
                </tr>
                <tr>   
                <td> 
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	  
        <br/>
      </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["alquiler_editar_s_error"];
        $error_mensaje = $_SESSION["alquiler_editar_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["alquiler_editar_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $recibo_editar_s_guardar = $_SESSION["recibo_editar_s_guardar"];
    if($recibo_editar_s_guardar == "Si") {
        $_SESSION["recibo_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "alquilados_buscar_alquilado_alquilado_alquileres_recibos_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_recibo() { 
        var errors="";
        var valor_vacio = document.forms['formulario_recibo'].elements['recibo_descripcion_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Descripción no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_recibo'].elements['recibo_monto_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Monto no debe estar vacio</font>';
        } 
        var monto = document.forms['formulario_recibo'].elements['recibo_monto_editar'].value;
        // Chequea si el monto es un número
        if(errors == "" && isNaN(monto)) {
            errors += '<font style="color:red">El Monto debe ser un número</font>';    
        }
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>