<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Se presionó el botón guardar
	if (isset($_POST["recibo_descripcion_crear"])) {
		$_SESSION["recibo_descripcion_crear"] = $_POST["recibo_descripcion_crear"];
		$_SESSION["recibo_fecha_crear"] = $_POST["recibo_fecha_crear"];
		$_SESSION["recibo_monto_crear"] = $_POST["recibo_monto_crear"];
		// Mensaje si desea guardar datos
		$_SESSION["recibo_crear_s_guardar"] = "Si";
		echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos_crear.php'</script>";
	}
?>