<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    } 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Validar formulario alquiler con php
	$id_alquiler = $_SESSION["id_alquiler_editar_alquileres"];
	if (isset($_POST["alquiler_bien_editar"])) {
		// Asignar valores a variables de sesiones
		$_SESSION["alquiler_bien_editar"] = trim($_POST["alquiler_bien_editar"]);
		$_SESSION["alquiler_descripcion_editar"] = $_POST["alquiler_descripcion_editar"];
		$_SESSION["alquiler_fecha_editar"] = $_POST["alquiler_fecha_editar"];
		$_SESSION["alquiler_monto_editar"] = $_POST["alquiler_monto_editar"];
		// Ids de los alquileres
 		$id_alquiler_actual_editar = $_SESSION["alquiler_actual_editar"];
		$id_alquiler_bien_editar = $_SESSION["alquiler_bien_editar"];
		// Si el Alquiler ya existe
		if ($id_alquiler_actual_editar != $id_alquiler_bien_editar) {
			$sql_alquiler = "SELECT id_bien FROM tab_alquileres WHERE (id_bien = $id_alquiler_bien_editar)";
			$query_alquiler = $mysqli->query($sql_alquiler);
			$row_alquiler = $query_alquiler->fetch_assoc();
			$nro_registros_alquiler = $query_alquiler->num_rows;
			if($nro_registros_alquiler != 0) {
				$_SESSION["alquiler_editar_s_error"] = "Si";
				$_SESSION["alquiler_editar_error_mensaje"] = "El Bien ya está alquilado";
				echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_editar.php?id_alquilado=$id_alquiler'</script>";
				exit();	
			} 
		} // if ($alquilado_actual_nro_identidad != $alquilado_nro_identidad)
	// Validación formulario bien correcta
	$_SESSION["alquiler_editar_s_guardar"] = "Si";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_editar.php?id_alquiler=".$id_alquiler."'</script>";
	}
?>