<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Usuario
    $alquilado_usuario = $_SESSION["usuario_usuario"];
	$id_alquilado = $_SESSION["alquilados_buscar_alquilado_editar_id_alquilado"];
	$alquilado_nro_identidad = $_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"];
	$alquilado_nombre = $_SESSION["alquilados_buscar_alquilado_editar_nombre"];
	$alquilado_apellido = $_SESSION["alquilados_buscar_alquilado_editar_apellido"];
	// Actualizar datos del Alquilado
	$sql2 = "UPDATE tab_alquilados SET nro_identidad='$alquilado_nro_identidad',nombre='$alquilado_nombre',apellido='$alquilado_apellido',usuario='$alquilado_usuario',fecha_usuario_reg=Current_Timestamp WHERE id_alquilado='$id_alquilado'";
	$query2=$mysqli->query($sql2);
	// Borrar variables de sesiones
	unset($_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"]);
	unset($_SESSION["alquilados_buscar_alquilado_editar_nombre"]);
	unset($_SESSION["alquilados_buscar_alquilado_editar_apellido"]);
	// Mensaje
	$_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "Si";
	$_SESSION["alquilados_buscar_alquilado_editar_s_guardar_contenido"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado.php?nro_identidad=$alquilado_nro_identidad'</script>";
?>