<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
  // Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
    header("Location:error1.php");
    exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
    header("Location:error1.php");
    exit();
  }
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
    header("Location:error1.php");
    exit();
  }
  // Buscar datos del recibo
  $id_recibo_reg = $_GET["id_recibo"];
  $sql2 = "SELECT id_recibo, id_alquiler, descripcion, anulado, fecha_recibo_reg, monto ";
  $sql2 .= "FROM tab_recibos WHERE (id_recibo = $id_recibo_reg)";
  $query2 = $mysqli->query($sql2);
  $nro_registros = $query2->num_rows;
  $row2 = $query2->fetch_assoc();
  if($nro_registros != 0) {
    $fecha_recibo = date_create($row2['fecha_recibo_reg']);
    $fecha_recibo_2 = date_format($fecha_recibo,'d-m-Y');
    $id_alquiler = $row2['id_alquiler'];
    $descripcion = $row2['descripcion'];
    $monto = $row2['monto'];
  } else {
    echo "No se encuentra el recibo";
    exit;
  }  
  // Buscar el alquilado y el bien del recibo
  $sql8 = "SELECT id_alquiler, id_alquilado, id_bien FROM tab_alquileres ";
  $sql8 .=	"WHERE (id_alquiler = ".$id_alquiler.")";
  $query8 = $mysqli->query($sql8);
  $row8 = $query8->fetch_assoc();
  $nro_registros_8 = $query8->num_rows;
  if($nro_registros_8!=0) {
    $id_alquilado = $row8['id_alquilado'];
    $id_bien = $row8['id_bien'];
  } else {
    $id_alquilado = 0;
    $id_bien = 0;
  }
  // Buscar nombre del alquilado del recibo
  $sql9 = "SELECT id_alquilado, nro_identidad, nombre, apellido FROM tab_alquilados ";
  $sql9 .= "WHERE (id_alquilado = ".$id_alquilado.")";
  $query9 = $mysqli->query($sql9);
  $row9 = $query9->fetch_assoc();
  $nro_registros_9 = $query9->num_rows;
  if($nro_registros_9!=0) {
    $nro_identidad = $row9['nro_identidad'];
    $nombre = $row9['nombre']." ".$row9['apellido'];
  } else {
    $nro_identidad = "???";
    $nombre = "???";
  }						
  // Buscar bien alquilado del recibo
  $sql10 = "SELECT id_bien, bien, descripcion FROM tab_bienes ";
  $sql10 .= "WHERE (id_bien = ".$id_bien.")";
  $query10 = $mysqli->query($sql10);
  $row10 = $query10->fetch_assoc();
  $nro_registros_10 = $query10->num_rows;
  if($nro_registros_10!=0) {
    $bien = $row10['bien'].", ".$row10['descripcion'];
  } else {
    $bien = "???";
  }				
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>mini Rentas - Recibos - Imprimir</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	  <!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <script>
      function printe(){
        //desaparece el boton
        document.getElementById("menu").style.display='none';
        document.getElementById("volver").style.display='none';
        document.getElementById("Imprimir").style.display='none';
        //se imprime la pagina
        window.print();
        //reaparece el boton
        document.getElementById("menu").style.display='inline';
        document.getElementById("volver").style.display='inline';
        document.getElementById("Imprimir").style.display='inline';
      }
    </script>
</head>
<body>
	<div class="contenedor-2">
    <div style="overflow-x:auto">
       <div>        
          <div style="float:left">  
            <img src='imagen/antonella.png' alt='logo minirentas' width='320px' height='50px'>
          </div>
          <div style="float:left; padding-left:20px">  
            <font class="font7">Fecha: <?php echo $fecha_recibo_2 ?> </font>
            <br/>
            <font class="font7">Recibo:<?php echo "#".$id_recibo_reg ?></font>
          </div>
        </div>      
        <div style="clear:both">
        </div>  
        <hr>
        <font class="font6">Nro. Identidad: <?php echo $nro_identidad ?></font>
        <br/>
        <font class="font6">Nombre: <?php echo $nombre ?></font>
        <br/>
        <font class="font6">Bien: <?php echo $bien; ?></font>
        <br/>
        <font class="font6"><b>Descripción: </b>
        <?php 
          if($row2['anulado'] == "No") {
            echo $descripcion;
          } else {
            echo $descripcion." <span class='anulado'><b>(Anulado)</b></span>";
          }  
        ?>
        </font>
        <hr>
        <br/>
        <font class="font8">Monto:<?php echo number_format($monto,2,',','.'); ?></font>
        <hr>
        <span class="empresa">	
			    Usuario: <?php echo $_SESSION["usuario_usuario"]; ?>
		    <br/>
          <?php 
            // mini Sistemas cjcv
            require("mini.php"); 
          ?>
        </span>  
        <br/>
        <br/>
		    <a id="menu" href="menu.php"><font class="font7">Menú</font></a>&nbsp&nbsp
        <a id="volver" href="alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=<?php echo $id_alquiler ?>">Volver</a>&nbsp&nbsp
        <a id="Imprimir" href="#" onclick="printe()"><font class="font7">Imprimir</font></a> 
        <br/><br/>
	  </div> <!-- class="contenedor card texto-centrado" -->	 
  </div> <!-- class="contenedor" -->
</body>
</html> 