<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Bien
	$bien = $_SESSION["bien_bien_crear"];
	$bien_descripcion = $_SESSION["bien_descripcion_crear"];
    $bien_direccion = $_SESSION["bien_direccion_crear"];
	$bien_fecha = $_SESSION["bien_fecha_crear"];
	$bien_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_bien = $bien_fecha;
    $fecha_bien = trim($fecha_bien);
    $fecha_bien_li_valores = explode('/', $fecha_bien);
    $fecha_bien_1i = "$fecha_bien_li_valores[2]-$fecha_bien_li_valores[1]-$fecha_bien_li_valores[0]";
	// Guardar nuevo Bien	
	$sql="INSERT INTO tab_bienes (bien, descripcion, direccion, fecha_bien_reg, usuario, fecha_usuario_reg) ";
	$sql.="VALUES ('$bien','$bien_descripcion','$bien_direccion','$fecha_bien_1i','$bien_usuario',Current_Timestamp)";
    $query=$mysqli->query($sql);
    /* Destruir las variables la variables de sesiones
    de los datos del Bien nuevo */ 
    unset($_SESSION["bien_bien_crear"]);
	unset($_SESSION["bien_descripcion_crear"]);
    unset($_SESSION["bien_direccion_crear"]);
    unset($_SESSION["bien_fecha_crear"]);
    // Mensaje de dato guardado
    $_SESSION["mensaje_bien_editar"] = "Si";
	$_SESSION["mensaje_contenido_bien_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'bienes.php'</script>";
?>