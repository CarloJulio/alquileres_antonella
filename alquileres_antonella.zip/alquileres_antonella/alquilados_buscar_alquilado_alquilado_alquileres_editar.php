<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["alquiler_editar_s_error"])){
        $_SESSION["alquiler_editar_s_error"] = "No";
    }
    if (!isset($_SESSION["alquiler_editar_error_mensaje"])){
        $_SESSION["alquiler_editar_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["alquiler_editar_s_guardar"])){
        $_SESSION["alquiler_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["alquiler_bien_editar"])){
        $_SESSION["alquiler_bien_editar"] = "";
    }
    if (!isset($_SESSION["alquiler_actual_editar"])){
        $_SESSION["alquiler_actual_editar"]  = "";
    }
    if (!isset($_SESSION["alquiler_descripcion_editar"])){
        $_SESSION["alquiler_descripcion_editar"] = "";
    }
    if (!isset($_SESSION["alquiler_fecha_editar"])){
        $_SESSION["alquiler_fecha_editar"] = "";
    }
    if (!isset($_SESSION["alquiler_monto_editar"])){
        $_SESSION["alquiler_monto_editar"] = "";
    }
    if (!isset($_SESSION["alquiler_usuario_editar"])){
        $_SESSION["alquiler_usuario_editar"] = "";
    }
    // El alquiler seleccionado para editar
    if (isset($_GET["id_alquiler"])) {
        $id_alquiler = $_GET["id_alquiler"];  
        $_SESSION["id_alquiler_editar_alquileres"] = $_GET["id_alquiler"];  
        $sql_alquiler = "SELECT id_alquiler, id_bien, descripcion, fecha_alquiler_reg, monto, usuario FROM tab_alquileres WHERE (id_alquiler = $id_alquiler)";
        $query_alquiler = $mysqli->query($sql_alquiler);
        $row_alquiler = $query_alquiler->fetch_assoc();
        $nro_registros_alquiler = $query_alquiler->num_rows;
        if($nro_registros_alquiler != 0) {
            $id_bien = $row_alquiler['id_bien'];
            $descripcion = $row_alquiler['descripcion'];
            $fecha = $row_alquiler['fecha_alquiler_reg'];
            $monto = $row_alquiler['monto'];
            $usuario = $row_alquiler['usuario'];
            // Pasar fecha a formato español
            $fecha_bien = $fecha;
            $fecha_bien = trim($fecha_bien);
            $fecha_bien_li_valores = explode('-', $fecha_bien);
            $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
            // Iniciar variables de sesiones
            if(empty($_SESSION["alquiler_bien_editar"])) {
                $_SESSION["alquiler_bien_editar"] = $id_bien;
            }
            $_SESSION["alquiler_actual_editar"] = $id_bien;
            if(empty($_SESSION["alquiler_descripcion_editar"])) {
                $_SESSION["alquiler_descripcion_editar"] = $descripcion;
            }
            if(empty($_SESSION["alquiler_fecha_editar"])) {
                $_SESSION["alquiler_fecha_editar"] = $fecha_bien_1i;
            }
            if(empty($_SESSION["alquiler_monto_editar"])) {
                $_SESSION["alquiler_monto_editar"] = $monto;
            }
            $_SESSION["alquiler_usuario_editar"] = $usuario;
        } else {
            echo "No se encuentra el Alquiler";
            exit();
        }
    } // if (isset($_GET["id_alquiler"]))
    // Bienes 
    $sqlsu = "SELECT id_bien, bien, descripcion FROM tab_bienes ORDER BY bien";;
    $querysu = $mysqli->query($sqlsu);
    $combobit3="";
    while ($rowsu=$querysu->fetch_assoc()) { 
        if($rowsu['id_bien'] == $_SESSION["alquiler_bien_editar"]){
            $combobit3.=" <option value='".$rowsu['id_bien']."' selected='selected'>".$rowsu['bien']." - ".$rowsu['descripcion']."</option>"; 
        }else{
            $combobit3.=" <option value='".$rowsu['id_bien']."'>".$rowsu['bien']." - ".$rowsu['descripcion']."</option>";  
        }
    }
    // Datos del Alquilado
    $id_alquilado = $_SESSION["id_alquilado"];
    $alquilado_nro_identidad = $_SESSION["alquilado_nro_identidad"];
    $alquilado_nombre = $_SESSION["alquilado_nombre"];
    $alquilado_apellido = $_SESSION["alquilado_apellido"];
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquileres - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Alquileres - Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=<?php echo $id_alquilado ?>">Volver</a>
      <br/><br/>
      <font class="font2">Id Alquilado: <?php echo $id_alquilado; ?></font><br/>
      <font class="font2">Nro. Identidad: <?php echo $alquilado_nro_identidad; ?></font><br/>
      <font class="font2">Nombre: <?php echo $alquilado_nombre; ?></font><br/>
      <font class="font2">Apellido: <?php echo $alquilado_apellido; ?></font><br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Editar Alquiler</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
        <div style="overflow-x:auto"> 
		<form name="formulario_alquiler" method="POST" action="alquilados_buscar_alquilado_alquilado_alquileres_editar_validar_1.php" onsubmit="validar_formulario_alquiler();return document.MM_returnValue">
            <table class="tab6" align="center">	
                <tr>   
                <td> 
                    <label><b>Bien</b></label>
                    <select class="input" name="alquiler_bien_editar" ><?php echo $combobit3;?></select>
                </td>
                </tr>
                <tr>   
                <td> 
                    <label><b>Descripción</b></label>
                    <input class="input" type="text" name="alquiler_descripcion_editar" maxlength="255" value="<?php echo $_SESSION["alquiler_descripcion_editar"] ?>">
                </td>
                </tr>
                <tr>   
                <td>  
                    <label><b>Fecha</b></label>
                    <input class="input" type="text" name="alquiler_fecha_editar" id="datepicker" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION["alquiler_fecha_editar"] ?>"/>
                </td>
                </tr>
                <tr>   
                <td>    
                    <label><b>Monto</b></label>
                    <input class="input" type="text" name="alquiler_monto_editar" maxlength="15" value="<?php echo $_SESSION["alquiler_monto_editar"] ?>">
                </td>
                </tr>
                <tr>   
                <td> 
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	  
        <br/>
      </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["alquiler_editar_s_error"];
        $error_mensaje = $_SESSION["alquiler_editar_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["alquiler_editar_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $bien_editar_s_guardar = $_SESSION["alquiler_editar_s_guardar"];
    if($bien_editar_s_guardar == "Si") {
        $_SESSION["alquiler_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "alquilados_buscar_alquilado_alquilado_alquileres_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_alquiler() { 
        var errors="";
        var valor_vacio = document.forms['formulario_alquiler'].elements['alquiler_descripcion_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Descripción no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_alquiler'].elements['alquiler_monto_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Monto no debe estar vacio</font>';
        } 
        var monto = document.forms['formulario_alquiler'].elements['alquiler_monto_editar'].value;
        // Chequea si el monto es un número
        if(errors == "" && isNaN(monto)) {
            errors += '<font style="color:red">El Monto debe ser un número</font>';    
        }
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>