<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
       header("Location:error1.php");
       exit();
    } 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    if (!isset($_SESSION['recibos_fecha_1'])) {
        $sql = "SELECT current_date";
        $row = $mysqli->query($sql);
        $consultaf = $row->fetch_assoc();
        $fechadelmysql = date_create($consultaf['current_date']);
        $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
        $fechard1 = $fechadelmysql;
        $fechard1=trim($fechard1);
        $fechard1_valores = explode('-', $fechard1);
        $fechard2 = "$fechard1_valores[0]/$fechard1_valores[1]/$fechard1_valores[2]";
        $_SESSION['recibos_fecha_1'] = $fechard2;
    }
    if (!isset($_SESSION['recibos_fecha_2'])) {
        $sql = "SELECT current_date";
        $row = $mysqli->query($sql);
        $consultaf = $row->fetch_assoc();
        $fechadelmysql = date_create($consultaf['current_date']);
        $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
        $fechard1 = $fechadelmysql;
        $fechard1=trim($fechard1);
        $fechard1_valores = explode('-', $fechard1);
        $fechard2 = "$fechard1_valores[0]/$fechard1_valores[1]/$fechard1_valores[2]";
        $_SESSION['recibos_fecha_2'] = $fechard2;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Recibos - Fechas</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker1" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
            $( "#datepicker2" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        } );
    </script>
</head>
<body>
    <div class="contenedor">
      <h3>
        <font class="font1">Recibos - Fechas</font><br/>
      </h3>   
      <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="menu_alquilados.php">Volver</a>&nbsp&nbsp
      <br/><br/>
      <h3><font class="font1">Buscar Fechas</font></h3>    
      <form method="POST" action="recibos_fechas_lista.php">
        <div style="overflow-x:auto">
            <table style="width:400px">
                <tr>
                    <td>    
                        <label><b>Fecha (desde)</b></label>
                        <input type="text" name="recibos_fecha_1" id="datepicker1" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION['recibos_fecha_1'] ?>"/>
                    </td> 
                    <td>   
                        <label><b>Fecha (hasta)</b></label>
                        <input type="text" name="recibos_fecha_2" id="datepicker2" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION['recibos_fecha_2'] ?>"/>
                    </td>  
                </tr>
                <tr>
                    <td>      
                        <button class="boton"><b>Recibos</b></button>
                    </td>  
                </tr>
            <table>
        </div>    
      </form>
    </div>  <!-- class="contenedor card texto-izquierdo" -->
</body>
</html>