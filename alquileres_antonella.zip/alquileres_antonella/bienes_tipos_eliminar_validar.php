<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
	// Chequear si la sesión de usuario está vacio
  	if (empty($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	}
	$id_bien_tipo = $_GET["id_bien_tipo"];
	// tabla bienes
	$sql_bien_tipo = "DELETE FROM tab_bienes_tipos WHERE (id_bien_tipo = ".$id_bien_tipo.")";
  	$query_bien_tipo = $mysqli->query($sql_bien_tipo);
	// Mensaje Usuario eliminado
	$_SESSION["mensaje_bien_tipo_editar"] = "Si";
	$_SESSION["mensaje_contenido_bien_tipo_editar"] = "Bien Tipo Eliminado con Éxito.";
	echo "<script>location.href = 'bienes_tipos.php'</script>";
?>