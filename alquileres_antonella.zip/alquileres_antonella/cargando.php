<?php
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="utf-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Alquileres Antonella - Cargando</title>
    <!-- Anillo cargando y cerrando -->
    <link href="css/anillo.css" rel="stylesheet">
	<link rel="shortcut icon" href="imagen/avatar.png" />
<script>
// Tarda 1 segundo en abrir el archivo menu.php
setTimeout(myFunction, 1000)
function myFunction() {
  location.href = "menu.php";
}
</script>
</head>
<body>
<div class="loading show">
    <!-- Capa donde se dibuja el anillo -->
   	<div class="spin"></div>
</div>
</body>
</html>