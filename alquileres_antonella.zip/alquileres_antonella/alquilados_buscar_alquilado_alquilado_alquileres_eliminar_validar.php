<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del alquiler
	$id_alquiler = $_GET["id_alquiler"];
	$id_alquilado = $_SESSION["id_alquilado"];
	// Tabla  de recibos
	$sql_recibo = "SELECT id_alquiler FROM tab_recibos WHERE (id_alquiler = $id_alquiler)";
	$query_recibo = $mysqli->query($sql_recibo);  
	$nro_registros = $query_recibo->num_rows;      
	// Si el alquiler tiene recibos  
	if($nro_registros!=0) {  
		$_SESSION["mensaje_alquiler_editar"] = "No";
		$_SESSION["mensaje_alquiler_error_editar"] = "Si";
		$_SESSION["mensaje_contenido_alquiler_editar"] = "Alquiler no se pudo Eliminar, tiene recibos";
	}  else {  	
		// Tabla alquileres
		$sql_alquiler = "DELETE FROM tab_alquileres WHERE (id_alquiler = ".$id_alquiler.")";
  		$query_alquiler = $mysqli->query($sql_alquiler);
		// Mensaje Alquiler eliminado
		$_SESSION["mensaje_alquiler_editar"] = "Si";
		$_SESSION["mensaje_alquiler_error_editar"] = "No";
		$_SESSION["mensaje_contenido_alquiler_editar"] = "Alquiler Eliminado con Éxito.";
	}	
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=".$id_alquilado."'</script>";
?>