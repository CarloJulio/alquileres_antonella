<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	$id_recibo = $_SESSION["id_recibo_editar_recibos"]; 
	// Se presionó el botón guardar
	if (isset($_POST["recibo_descripcion_editar"])) {
		$_SESSION["recibo_descripcion_editar"] = $_POST["recibo_descripcion_editar"];
		$_SESSION["recibo_fecha_editar"] = $_POST["recibo_fecha_editar"];
		$_SESSION["recibo_monto_editar"] = $_POST["recibo_monto_editar"];
		// Mensaje si desea guardar datos
		$_SESSION["recibo_editar_s_guardar"] = "Si";
		echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos_editar.php?id_recibo=".$id_recibo."'</script>";
	}
?>