<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Alquiler
	$id_alquiler = $_SESSION["id_alquiler"];
	$recibo_descripcion = $_SESSION["recibo_descripcion_crear"];
	$recibo_fecha = $_SESSION["recibo_fecha_crear"];
	$recibo_monto = $_SESSION["recibo_monto_crear"];
	$recibo_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_recibo = $recibo_fecha;
    $fecha_recibo = trim($fecha_recibo);
    $fecha_recibo_li_valores = explode('/', $fecha_recibo);
    $fecha_recibo_1i = "$fecha_recibo_li_valores[2]-$fecha_recibo_li_valores[1]-$fecha_recibo_li_valores[0]";
	// Guardar nuevo Alquiler	
	$sql="INSERT INTO tab_recibos (id_alquiler, descripcion, fecha_recibo_reg, monto, usuario, fecha_usuario_reg) ";
	$sql.="VALUES ('$id_alquiler','$recibo_descripcion','$fecha_recibo_1i','$recibo_monto','$recibo_usuario',Current_Timestamp)";
    $query=$mysqli->query($sql);
    /* Destruir las variables la variables de sesiones
    de los datos del recibo nuevo */ 
    unset($_SESSION["recibo_descripcion_crear"]);
    unset($_SESSION["recibo_fecha_crear"]);
	unset($_SESSION["recibo_monto_crear"]);
	// Mensaje de datos guardado
    $_SESSION["mensaje_recibo_editar"] = "Si";
	$_SESSION["mensaje_contenido_recibo_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=".$id_alquiler."'</script>";
?>