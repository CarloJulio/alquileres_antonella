<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	// Iniciar sesión del Usuario  
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
  	$id_usuario = $_GET["id_usuario"];
	$usuario = $_GET["usuario"];
	// Chequear si el Usuario tiene datos relacionados con bienes
	$sql_bien = "SELECT usuario FROM tab_bienes WHERE (usuario = '$usuario')";
	$query_bien = $mysqli->query($sql_bien);
	$row_bien = $query_bien->fetch_assoc();
	$nro_registros_bien = $query_bien->num_rows;
	if($nro_registros_bien != 0) {
   		$_SESSION["usuario_editar_s_error"] = "Si";
		$_SESSION["usuario_editar_error_mensaje"] = "No se puede Eliminar El Usuario, <br/> tienes datos relacionados en bienes";
		echo "<script>location.href = 'usuarios.php'</script>";
		exit();	
	} 
	// tabla usuarios
	$sql_usuario = "DELETE FROM tab_usuarios WHERE (id_usuario = ".$id_usuario.")";
  	$query_usuario = $mysqli->query($sql_usuario);
	// Mensaje Usuario eliminado
	$_SESSION["mensaje_usuario_editar"] = "Si";
	$_SESSION["mensaje_contenido_usuario_editar"] = "Usuario Eliminado con Éxito.";
	echo "<script>location.href = 'usuarios.php'</script>";
?>