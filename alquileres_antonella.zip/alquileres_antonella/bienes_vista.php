<?php
  // Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de bien esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }   
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
	$id_bien = $_GET["id_bien"];
  // Buscar datos del bien
  $sql = "SELECT id_bien, bien, descripcion, direccion, fecha_bien_reg ";
  $sql .= "FROM tab_bienes WHERE (id_bien = ".$id_bien.")";
  $query = $mysqli->query($sql);
  $nro_registros = $query->num_rows;
  $row = $query->fetch_assoc();
  // Si existe el bien
  if($nro_registros != 0) {
    // Datos del bien
    $id_bien = $row['id_bien'];
    $bien = $row['bien'];
    $descripcion = $row['descripcion'];
    $direccion = $row['direccion'];
    $fecha = $row['fecha_bien_reg'];
    // Pasar fecha a formato español
    $fecha_bien = $row['fecha_bien_reg'];
    $fecha_bien = trim($fecha_bien);
    $fecha_bien_li_valores = explode('-', $fecha_bien);
    $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
    $fecha = $fecha_bien_1i;
  } else {
    echo "bien no encontrado";
    exit;
  }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
  <!-- Caracteres en español -->
	<meta charset="UTF-8">
  <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes - Vista</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	  <!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <script>
      function printe(){
        //desaparece el boton
        document.getElementById("menu").style.display='none';
        document.getElementById("volver").style.display='none';
        document.getElementById("Imprimir").style.display='none';
        //se imprime la pagina
        window.print();
        //reaparece el boton
        document.getElementById("menu").style.display='inline';
        document.getElementById("volver").style.display='inline';
        document.getElementById("Imprimir").style.display='inline';
      }
    </script>
</head>
<body>
	<div class="contenedor">
        <!-- Datos de bien -->
        <font class="font6"><b>Bien</b></font>
        <br/><br/>
        <font class="font6">Id Bien: <?php echo $id_bien ?></font>
        <br/>
        <font class="font6">Bien: <?php echo $bien ?></font>
        <br/>
        <font class="font6">Descripción: <?php echo $descripcion ?></font>
        <br/>
        <font class="font6">Dirección: <?php echo $direccion ?></font>
        <br/>
        <font class="font6">Fecha: <?php echo $fecha ?></font>
        <br/><br/>
        <font class="font6">
        <span class="empresa">
        <?php 
          // mini Sistemas cjcv
          require("mini.php"); 
        ?>
        </span>
        </font>
        <br/>
        <br/>
        <!-- Enlaces -->
		    <a id="menu" href="menu.php"><font class="font7">Menú</font></a>&nbsp&nbsp
        <a id="volver" href="bienes.php">Volver</a>&nbsp&nbsp
        <a id="Imprimir" href="#" onclick="printe()"><font class="font7">Imprimir</font></a> 
        <br/><br/>
	  </div> <!-- class="contenedor card texto-centrado" -->	 
  </div> <!-- class="contenedor" -->
</body>
</html> 