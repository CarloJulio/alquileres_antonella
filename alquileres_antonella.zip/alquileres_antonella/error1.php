<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
	<!-- Caracteres en español -->
    <meta charset="UTF-8">
	<!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<title>mini - Rentas - Error 1</title> 
	<link rel="shortcut icon" href="imagen/avatar.png" />
</head>
<body>
	<div class="contenedor">
		<p>
			<font class="font4">Debes ingresar al sistema nuevamente</font>
			<br/>
			<a href='index.php'><font class="font4">ir a la P&#225gina Iniciar Sesión</font></a>

		</p>
	</div>
</body>
</html>