<?php
    require("conexion/conexion.php");
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    if (!isset($_SESSION["usuario_editar_s_error"])){
        $_SESSION["usuario_editar_s_error"] = "No";
    }
    if (!isset($_SESSION["usuarios_editar_s_guardar"])){
        $_SESSION["usuarios_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["usuario_editar_error_mensaje"])){
        $_SESSION["usuario_editar_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["usuario_usuario_editar"])){
        $_SESSION["usuario_usuario_editar"] = "";
    }
    if (!isset($_SESSION["usuario_actual_editar"])){
        $_SESSION["usuario_actual_editar"]  = "";
    }
    if (!isset($_SESSION["usuario_clave_editar"])){
        $_SESSION["usuario_clave_editar"] = "";
    }
    if (!isset($_SESSION["usuario_nombres_editar"])){
        $_SESSION["usuario_nombres_editar"] = "";
    }
    if (!isset($_SESSION["usuario_apellidos_editar"])){
        $_SESSION["usuario_apellidos_editar"] = "";
    }
    if (!isset($_SESSION["usuario_rol_editar"])){
        $_SESSION["usuario_rol_editar"] = "";
    }
    // El Usuario seleccionado para editar
    if (isset($_GET["id_usuario"])) {
        $id_usuario = $_GET["id_usuario"];  
        $_SESSION["id_usuario_editar_herramientas"] = $_GET["id_usuario"];  
        $sql_usuario = "SELECT id_usuario, usuario, clave, nombre, apellido, rol FROM tab_usuarios WHERE (id_usuario = $id_usuario)";
        $query_usuario = $mysqli->query($sql_usuario);
        $row_usuario = $query_usuario->fetch_assoc();
        $nro_registros_usuario = $query_usuario->num_rows;
        if($nro_registros_usuario != 0) {
            $usuario = $row_usuario['usuario'];
            $clave = $row_usuario['clave'];
            $nombres = $row_usuario['nombre'];
            $apellidos = $row_usuario['apellido'];
            $rol = $row_usuario['rol'];
        } else {
            echo "No se encuentra el Usuario";
            exit();
        }
        $_SESSION["usuario_usuario_editar"] = $usuario;
        $_SESSION["usuario_actual_editar"] = $usuario;
        $_SESSION["usuario_clave_editar"] = $clave;
        $_SESSION["usuario_nombres_editar"] = $nombres;
        $_SESSION["usuario_apellidos_editar"] = $apellidos;
        $_SESSION["usuario_rol_editar"] = $rol;
    } // if (isset($_GET["id_usuario"]))
    // Rol usuario 
    $sqlsu="SELECT id_rol, rol FROM tab_roles ORDER BY rol";
    $querysu = $mysqli->query($sqlsu);
    $combobit3="";
    while ($rowsu=$querysu->fetch_assoc()) { 
        if($rowsu['rol'] == $_SESSION["usuario_rol_editar"]){
            $combobit3.=" <option value='".$rowsu['rol']."' selected='selected'>".$rowsu['rol']."</option>"; 
        }else{
            $combobit3.=" <option value='".$rowsu['rol']."'>".$rowsu['rol']."</option>"; 
        }
    }   
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Usuarios - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Usuarios- Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="usuarios.php">Volver</a>
      <br/><br/>
      <b>Id Usuario:</b>
      <?php echo $_SESSION["id_usuario_editar_herramientas"] ?>
      <br/>
      	<div class="contenedor texto-left">
        <div align="center">  
            <font class="font3">Editar Usuario</font>	  
        </div>
        <div style="overflow-x:auto"> 
        <form name="formulario_usuario" method="POST" action="usuarios_editar_validar_1.php" onsubmit="validar_formulario_usuario();return document.MM_returnValue">
		<table class="tab5" align="center">	
            <tr>   
            <td> 
                <label><b>Usuario</b></label>
           		<input class="input1" type="text" name="usuario_usuario_editar" maxlength="20" autofocus value="<?php echo $_SESSION["usuario_usuario_editar"] ?>">
            </td>
            </tr>
            <tr>   
            <td>   
                <label><b>Contraseña</b></label>
                <input class="input1" type="text" name="usuario_clave_editar" maxlength="20" value="<?php echo $_SESSION["usuario_clave_editar"] ?>">
            </td>
            </tr>
            <tr>   
            <td>   
                <label><b>Nombre</b></label>
                <input class="input1" type="text" name="usuario_nombres_editar" maxlength="50" value="<?php echo $_SESSION["usuario_nombres_editar"] ?>">
            </td>
            </tr>
            <tr>   
            <td>   
                <label><b>Apellido</b></label>
                <input class="input1" type="text" name="usuario_apellidos_editar" maxlength="50" value="<?php echo $_SESSION["usuario_apellidos_editar"] ?>">
            </td>
            </tr>
            <tr>   
            <td>   
                <label><b>Rol</b></label>
                <select class="input1" name="usuario_rol_editar" ><?php echo $combobit3;?></select>
            </td>
            </tr>
            <tr>   
            <td>   
                <input class="boton" type="submit" value="Guardar">
            </td>
            </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	
        </div> <!-- class="contenedor card texto-izquierdo" -->
	  <br/>
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["usuario_editar_s_error"];
        $error_mensaje = $_SESSION["usuario_editar_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["usuario_editar_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $usuario_editar_s_guardar = $_SESSION["usuarios_editar_s_guardar"];
    if($usuario_editar_s_guardar == "Si") {
        $_SESSION["usuarios_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "usuarios_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_usuario() { 
        var errors="";
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_usuario_editar'].value; 
        if (valor_vacio == "") {
            errors += '<font style="color:red">El Usuario no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_clave_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Contraseña no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_nombres_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Nombre no debe estar vacio</font>';
        }
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_apellidos_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Apellido no debe estar vacio</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>