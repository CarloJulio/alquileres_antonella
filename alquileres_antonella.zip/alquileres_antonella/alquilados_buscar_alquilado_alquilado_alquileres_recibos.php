<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  if (isset($_GET["id_alquiler"])) {
      $id_alquiler = $_GET["id_alquiler"];
      $_SESSION["id_alquiler"] = $id_alquiler;
  }else{
      echo "No se encuentra el id_alquiler del Alquiler";
      exit();
  }
  // Eliminar variables se sesión del formulario editar recibo
  unset($_SESSION["recibo_descripcion_editar"]);
  unset($_SESSION["recibo_fecha_editar"]);
  unset($_SESSION["recibo_monto_editar"]);
  // Iniciar variables
  if (!isset($_SESSION["id_recibo"])){
      $_SESSION["id_recibo"] = "";
  } 
  if (!isset($_SESSION["recibo_fecha"])){
      $_SESSION["recibo_fecha"] = "";
  } 
  // Mensaje de dato guardado
  if (!isset($_SESSION["mensaje_recibo_editar"])){
      $_SESSION["mensaje_recibo_editar"] = "";
  } 
  if (!isset($_SESSION["mensaje_contenido_recibo_editar"])){
      $_SESSION["mensaje_contenido_recibo_editar"] = "";
  } 
  // fecha actual, formato español
  $sql = "SELECT current_date";
  $row = $mysqli->query($sql);
  $consultaf = $row->fetch_assoc();
  $fechadelmysql = date_create($consultaf['current_date']);
  $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
  $_SESSION["fecha_hoy"] = $fechadelmysql;
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquileres - Recibos</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
  // Buscar el alquiler
  $sql2 = "SELECT id_alquiler, id_alquilado, id_bien, descripcion, monto ";
  $sql2 .= "FROM tab_alquileres WHERE (id_alquiler = $id_alquiler)";
  $query2 = $mysqli->query($sql2);
  $nro_registros2 = $query2->num_rows;
  if($nro_registros2!=0) {
    $row2=$query2->fetch_assoc();
    $id_alquiler = $row2['id_alquiler'];
    $id_alquilado = $row2['id_alquilado'];
    $id_bien = $row2['id_bien'];
    // Buscar el nombre de Bien
    $sql3 = "SELECT id_bien, bien, descripcion ";
    $sql3 .= "FROM tab_bienes WHERE (id_bien = $id_bien)";
    $query3 = $mysqli->query($sql3);
    $nro_registros3 = $query3->num_rows;
    if($nro_registros3!=0) {
      $row3=$query3->fetch_assoc();
      $bien = $row3['bien']." - ".$row3['descripcion'];
    } else {
      $bien = "???";
    }  
    $alquiler_descripcion = $row2['descripcion'];
    $alquiler_monto = $row2['monto'];
    $_SESSION["id_alquiler"] = $row2['id_alquiler'];
    $_SESSION["id_alquilado"] = $row2['id_alquilado'];
    $_SESSION["id_bien"] = $row2['id_bien'];
    $_SESSION["bien"] = $bien;
    $_SESSION["alquiler_descripcion"] = $alquiler_descripcion;
    $_SESSION["alquiler_monto"] = $alquiler_monto;
  } else {
    echo "No se encuentra el id_alquiler del Alquiler (tabla)";
    exit(); 
  }  
  // Buscar los recibos del alquiler
	$sql = "SELECT id_recibo, id_alquiler, descripcion, anulado, fecha_recibo_reg, monto ";
  $sql .= "FROM tab_recibos WHERE (id_alquiler = $id_alquiler) ORDER BY id_recibo";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Alquileres</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <a href="alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=<?php echo $id_alquilado ?>">Volver</a>
  <br/><br/>
  <font class="font2">Id Alquiler: <?php echo $id_alquiler; ?></font><br/>
  <font class="font2">Bien: <?php echo $bien; ?></font><br/>
  <font class="font2">Descripción: <?php echo $alquiler_descripcion; ?></font><br/>
  <font class="font2">Monto: <?php echo $alquiler_monto; ?></font><br/><br/>
  <div class="contenedor texto-centrado">
  	<h3><font class="font1">Recibos</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
 	<div style="overflow-x:auto">
    <table class="tab8" align="center">
         <thead>
        <tr class="tr4">
          <td>
            <a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos_crear.php">Crear</a>&nbsp&nbsp  
          </td>
        </tr>  
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr4">
	  				<th style="width:5%">Id</th>
            <th style="width:55%">Descripción</th>
      			<th style="width:8%">Fecha</th>
            <th style="width:10%">Monto</th>
      			<th >Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
         // Pasar fecha a formato español
          $fecha_recibo = $row['fecha_recibo_reg'];
          $fecha_recibo = trim($fecha_recibo);
          $fecha_recibo_li_valores = explode('-', $fecha_recibo);
          $fecha_recibo_1i = "$fecha_recibo_li_valores[2]/$fecha_recibo_li_valores[1]/$fecha_recibo_li_valores[0]";
      ?>
	    		<tr class="tr4">
    				<td align = "center"><?php echo $row['id_recibo']; ?></td>
    				<td>
            <?php 
              if( $row['anulado'] == "No") {
                echo $row['descripcion'];
              } else {
                echo $row['descripcion']." <span class='anulado'><b>(Anulado)</b></span>";
              }
            ?>
          </td>
        		<td align = 'center'><?php echo $fecha_recibo_1i ?></td>
            <td align = 'right'><?php echo number_format($row['monto'],2,',','.'); ?></td>
        		<td>
        				<a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos_vista.php?id_recibo=<?php echo $row['id_recibo']?>">Vista</a>
                <a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos_editar.php?id_recibo=<?php echo $row['id_recibo']?>">Editar</a>
                <?php 
                  if( $row['anulado'] == "No") {
                ?>    
                  <a href="#" onclick="anular_recibo(<?php echo $row['id_recibo']?>,'anular')">Anular</a>
                <?php 
                  } else {
                ?>          
                   <a href="#" onclick="anular_recibo(<?php echo $row['id_recibo']?>,'activar')">Activar</a>
                <?php 
                  } 
                ?>      
              </td> 
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr2'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Recibos</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_recibo_editar"] == "Si"){
        $_SESSION["mensaje_recibo_editar"]="No";
        $mensaje_alquiler_contenido = $_SESSION["mensaje_contenido_recibo_editar"];
    ?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_alquiler_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<script>
function anular_recibo(id_recibo,condicion) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Alquiler de Id:'+id_recibo+'?',
        html: '<span style="color:red">¿Deseas '+condicion+' el Recibo de Id:</span><span style="color:green">'+id_recibo+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos_anular_validar.php?id_recibo='+id_recibo+'&condicion='+condicion;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}      
</script>
</body>
</html>