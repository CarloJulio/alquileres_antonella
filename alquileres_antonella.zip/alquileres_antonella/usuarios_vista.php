<?php
  // Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
  // Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }   
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
	$id_usuario = $_GET["id_usuario"];
  // Buscar datos del Usuario
  $sql = "SELECT id_usuario, usuario, clave, nombre, apellido, rol ";
  $sql .= "FROM tab_usuarios WHERE (id_usuario = ".$id_usuario.")";
  $query = $mysqli->query($sql);
  $nro_registros = $query->num_rows;
  $row = $query->fetch_assoc();
  // Si existe el Usuario
  if($nro_registros != 0) {
    // Datos del Usuario
    $id_usuario = $row['id_usuario'];
    $usuario = $row['usuario'];
    $clave = $row['clave'];
    $nombre = $row['nombre'];
    $apellido = $row['apellido'];
    $rol = $row['rol'];
  } else {
    echo "Usuario no encontrado";
    exit;
  }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
  <!-- Caracteres en español -->
	<meta charset="UTF-8">
  <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Usuarios - Vista</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	  <!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <script>
      function printe(){
        //desaparece el boton
        document.getElementById("menu").style.display='none';
        document.getElementById("volver").style.display='none';
        document.getElementById("Imprimir").style.display='none';
        //se imprime la pagina
        window.print();
        //reaparece el boton
        document.getElementById("menu").style.display='inline';
        document.getElementById("volver").style.display='inline';
        document.getElementById("Imprimir").style.display='inline';
      }
    </script>
</head>
<body>
	<div class="contenedor">
        <!-- Datos de Usuario -->
        <font class="font6"><b>Usuario</b></font>
        <br/><br/>
        <font class="font6">Id Usuario: <?php echo $id_usuario ?></font>
        <br/>
        <font class="font6">Usuario: <?php echo $usuario ?></font>
        <br/>
        <font class="font6">Contraseña: <?php echo $clave ?></font>
        <br/>
        <font class="font6">Nombre: <?php echo $nombre ?></font>
        <br/>   
        <font class="font6">Apellido: <?php echo $apellido ?></font>
        <br/>   
        <font class="font6">Rol: <?php echo $rol ?></font>
        <br/>   
        <br/>
        <font class="font6">
        <span class="empresa">
        <?php 
          // mini Sistemas cjcv
          require("mini.php"); 
        ?>
        </span>
        </font>
        <br/>
        <br/>
        <!-- Enlaces -->
		    <a id="menu" href="menu.php"><font class="font7">Menú</font></a>&nbsp&nbsp
        <a id="volver" href="usuarios.php">Volver</a>&nbsp&nbsp
        <a id="Imprimir" href="#" onclick="printe()"><font class="font7">Imprimir</font></a> 
        <br/><br/>
	  </div> <!-- class="contenedor card texto-centrado" -->	 
  </div> <!-- class="contenedor" -->
</body>
</html> 