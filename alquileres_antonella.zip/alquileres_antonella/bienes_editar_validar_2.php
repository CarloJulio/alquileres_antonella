<?php
	// Conectar a la base de datos Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Datos del bien
	$id_bien = $_SESSION["id_bien_editar_bienes"];
	$bien_bien = $_SESSION["bien_bien_editar"];
	$bien_descripcion = $_SESSION["bien_descripcion_editar"];
	$bien_direccion = $_SESSION["bien_direccion_editar"];
	$bien_fecha = $_SESSION["bien_fecha_editar"];
	$bien_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_bien = $bien_fecha;
    $fecha_bien = trim($fecha_bien);
    $fecha_bien_li_valores = explode('/', $fecha_bien);
    $fecha_bien_1i = "$fecha_bien_li_valores[2]-$fecha_bien_li_valores[1]-$fecha_bien_li_valores[0]";
	// Actualizar datos del Bien
	$sql2 = "UPDATE tab_bienes SET bien='$bien_bien',descripcion='$bien_descripcion',direccion='$bien_direccion',fecha_bien_reg='$fecha_bien_1i',usuario='$bien_usuario',fecha_usuario_reg=Current_Timestamp WHERE id_bien='$id_bien'";
	$query2=$mysqli->query($sql2);
	$_SESSION["mensaje_bien_editar"] = "Si";
	$_SESSION["mensaje_contenido_bien_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'bienes.php'</script>";
?>