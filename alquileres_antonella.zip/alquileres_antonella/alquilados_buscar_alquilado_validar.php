<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Datos del formulario_buscar_alquilado
    if (isset($_POST["alquilados_buscar_alquilado_buscar_nro_identidad"])) {
    	$nro_identidad = $_POST["alquilados_buscar_alquilado_buscar_nro_identidad"];
    	$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"] = $_POST["alquilados_buscar_alquilado_buscar_nro_identidad"];
		// Buscar alquilado en la base de datos    
		$sql="SELECT id_alquilado, nro_identidad, nombre, apellido FROM tab_alquilados WHERE (nro_identidad = ".$nro_identidad.")";
		$row = $mysqli->query($sql);
		$fila = $row->fetch_assoc();
		$nro_registros=$row->num_rows;
		$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"] = "No";
		if($nro_registros != 0){ // Existe el alquilado
			$cedula = $fila['nro_identidad'];
			echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado.php?nro_identidad=$nro_identidad'</script>";
		} else { // Si no existe el alquilado
			$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"] = "Si";
			$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe_mensaje"] = "Nro. de Identidad no Existe";
			echo "<script>location.href = 'alquilados_buscar_alquilado.php'</script>";
		}	
    }
?>