<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["bien_tipo_crear_s_guardar"])){
        $_SESSION["bien_tipo_crear_s_guardar"] = "No";
    }
    if (!isset($_SESSION["bien_crear_s_error"])){
        $_SESSION["bien_crear_s_error"] = "No";
    }
    if (!isset($_SESSION["bien_crear_error_mensaje"])){
        $_SESSION["bien_crear_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["bien_tipo_crear"])){
        $_SESSION["bien_tipo_crear"] = "";
    }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes Tipos - Crear</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Bienes Tipos - Crear</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="bienes_tipos.php">Volver</a>
      <br/><br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Crear Bien Tipo</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
        <div style="overflow-x:auto"> 
		<form name="formulario_bien_tipo" method="POST" action="bienes_tipos_crear_validar_1.php" onsubmit="validar_formulario_bien_tipo();return document.MM_returnValue">
            <table class="tab10" align="center">	
                <tr>   
                <td>  
                    <label><b>Bien Tipo</b></label>
                    <input class="input" type="text" name="bien_tipo_crear" maxlength="20" value="<?php echo $_SESSION["bien_tipo_crear"] ?>">
                </td>
                </tr>
                <tr>   
                <td>  
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	
        <br/>
      </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["bien_crear_s_error"];
        $error_mensaje = $_SESSION["bien_crear_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["bien_crear_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $usuario_crear_s_guardar = $_SESSION["bien_tipo_crear_s_guardar"];
    if($usuario_crear_s_guardar == "Si") {
        $_SESSION["bien_tipo_crear_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "bienes_tipos_crear_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario bien con javascript
    function validar_formulario_bien_tipo() { 
        var errors="";
        var valor_vacio = document.forms['formulario_bien_tipo'].elements['bien_tipo_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">Bien Tipo no debe estar vacio</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>