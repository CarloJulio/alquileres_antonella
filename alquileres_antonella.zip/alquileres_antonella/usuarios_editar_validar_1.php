<?php
	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    } 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Validar formulario usuario con php
	$id_usuario = $_SESSION["id_usuario_editar_herramientas"];
	$usuario_actual = $_SESSION["usuario_actual_editar"];
	if (isset($_POST["usuario_usuario_editar"])) {
		$_SESSION["usuario_usuario_editar"] = trim($_POST["usuario_usuario_editar"]);
		$_SESSION["usuario_clave_editar"] = $_POST["usuario_clave_editar"];
		$_SESSION["usuario_nombres_editar"] = $_POST["usuario_nombres_editar"];
		$_SESSION["usuario_apellidos_editar"] = $_POST["usuario_apellidos_editar"];
		$_SESSION["usuario_rol_editar"] = $_POST["usuario_rol_editar"];
	    $usuario = trim($_POST["usuario_usuario_editar"]);
		// Si el Usuario ya existe
		if ($usuario_actual != $usuario) {
			$sql_usuario = "SELECT usuario FROM tab_usuarios WHERE (usuario = '$usuario')";
			$query_usuario = $mysqli->query($sql_usuario);
			$row_usuario = $query_usuario->fetch_assoc();
			$nro_registros_usuario = $query_usuario->num_rows;
			if($nro_registros_usuario != 0) {
   				$_SESSION["usuario_editar_s_error"] = "Si";
				$_SESSION["usuario_editar_error_mensaje"] = "El Usuario ya existe";
				echo "<script>location.href = 'usuarios_editar.php'</script>";
				exit();	
			} 
		} // if ($usuario_actual != $usuario)
		// Validación formulario usuario correcta
		$_SESSION["usuarios_editar_s_guardar"] = "Si";
		echo "<script>location.href = 'usuarios_editar.php'</script>";
	} // if (isset($_POST["usuario_usuario_editar"]))
?>