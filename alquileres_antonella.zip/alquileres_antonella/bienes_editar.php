<?php
    // Conectar a la base de datos Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Si la variable de sesiones si no está definido entonces definirlo
    if (!isset($_SESSION["bien_editar_s_guardar"])){
        $_SESSION["bien_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["bien_bien_editar"])){
        $_SESSION["bien_bien_editar"] = "";
    }
    if (!isset($_SESSION["bien_descripcion_editar"])){
        $_SESSION["bien_descripcion_editar"] = "";
    }
    if (!isset($_SESSION["bien_direccion_editar"])){
        $_SESSION["bien_direccion_editar"] = "";
    }
    if (!isset($_SESSION["bien_fecha_editar"])){
        $_SESSION["bien_fecha_editar"] = "";
    }
    if (!isset($_SESSION["bien_usuario_editar"])){
        $_SESSION["bien_usuario_editar"] = "";
    }
    // El Bien seleccionado para editar
    if (isset($_GET["id_bien"])) {
        $id_bien = $_GET["id_bien"];  
        $_SESSION["id_bien_editar_bienes"] = $_GET["id_bien"];  
        $sql_bien = "SELECT id_bien, bien, descripcion, direccion, fecha_bien_reg, usuario FROM tab_bienes WHERE (id_bien = $id_bien)";
        $query_bien = $mysqli->query($sql_bien);
        $row_bien = $query_bien->fetch_assoc();
        $nro_registros_bien = $query_bien->num_rows;
        if($nro_registros_bien != 0) {
            $bien = $row_bien['bien'];
            $descripcion = $row_bien['descripcion'];
            $direccion = $row_bien['direccion'];
            $fecha = $row_bien['fecha_bien_reg'];
            $usuario = $row_bien['usuario'];
            // Pasar fecha a formato español
            $fecha_bien = $fecha;
            $fecha_bien = trim($fecha_bien);
            $fecha_bien_li_valores = explode('-', $fecha_bien);
            $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
            // Iniciar variables de sesiones
            $_SESSION["bien_bien_editar"] = $bien;
            $_SESSION["bien_descripcion_editar"] = $descripcion;
            $_SESSION["bien_direccion_editar"] = $direccion;
            $_SESSION["bien_fecha_editar"] = $fecha_bien_1i;
            $_SESSION["bien_usuario_editar"] = $usuario;
        } else {
            echo "No se encuentra el Bien";
            exit();
        }
    } // if (isset($_GET["id_bien"]))
    // Tipos de bienes 
    $sqlsu="SELECT id_bien_tipo, bien_tipo FROM tab_bienes_tipos ORDER BY bien_tipo";
    $querysu = $mysqli->query($sqlsu);
    $combobit3="";
    while ($rowsu=$querysu->fetch_assoc()) { 
        if($rowsu['bien_tipo'] == $_SESSION["bien_bien_editar"]){
            $combobit3.=" <option value='".$rowsu['bien_tipo']."' selected='selected'>".$rowsu['bien_tipo']."</option>"; 
        }else{
            $combobit3.=" <option value='".$rowsu['bien_tipo']."'>".$rowsu['bien_tipo']."</option>"; 
        }
    }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Bienes - Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="bienes.php">Volver</a>
      <br/><br/>
      <b>Id Bien:</b>
      <?php echo $_SESSION["id_bien_editar_bienes"] ?>
      <br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Editar Bien</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
        <div style="overflow-x:auto"> 
		<form name="formulario_bien" method="POST" action="bienes_editar_validar_1.php" onsubmit="validar_formulario_bien();return document.MM_returnValue">
            <table class="tab6" align="center">	
                <tr>   
                <td> 
                    <label><b>Bien</b></label>
                    <select class="input" name="bien_bien_editar" ><?php echo $combobit3;?></select>
                </td>
                </tr>
                <tr>   
                <td> 
                    <label><b>Descripción</b></label>
                    <input class="input" type="text" name="bien_descripcion_editar" maxlength="255" value="<?php echo $_SESSION["bien_descripcion_editar"] ?>">
                </td>
                </tr>

                <tr>   
                <td> 
                    <label><b>Dirección</b></label>
                    <input class="input" type="text" name="bien_direccion_editar" maxlength="255" value="<?php echo $_SESSION["bien_direccion_editar"] ?>">
                </td>
                </tr>

                <tr>   
                <td>  
                    <label><b>Fecha</b></label>
                    <input class="input" type="text" name="bien_fecha_editar" id="datepicker" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION["bien_fecha_editar"] ?>"/>
                </td>
                </tr>
                <tr>   
                <td> 
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	  
        <br/>
      </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
    <?php
	$bien_editar_s_guardar = $_SESSION["bien_editar_s_guardar"];
    if($bien_editar_s_guardar == "Si") {
        $_SESSION["bien_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "bienes_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
    }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_bien() { 
        var errors="";
        var valor_vacio = document.forms['formulario_bien'].elements['bien_descripcion_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Descripción no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_bien'].elements['bien_direccion_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Dirección no debe estar vacio</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>