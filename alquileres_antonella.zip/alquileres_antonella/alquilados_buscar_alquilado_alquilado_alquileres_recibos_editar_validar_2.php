<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Datos del Recibo
	$id_recibo_editar = $_SESSION["id_recibo_editar_recibos"];
	$recibo_id_alquiler_editar = $_SESSION["id_alquiler"];
	$recibo_descripcion_editar = $_SESSION["recibo_descripcion_editar"];
	$recibo_fecha_editar = $_SESSION["recibo_fecha_editar"];
	$recibo_monto_editar = $_SESSION["recibo_monto_editar"];
 	$recibo_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_recibo_editar = $recibo_fecha_editar;
    $fecha_recibo_editar = trim($fecha_recibo_editar);
    $fecha_recibo_editar_li_valores = explode('/', $fecha_recibo_editar);
    $fecha_recibo_editar_1i = "$fecha_recibo_editar_li_valores[2]-$fecha_recibo_editar_li_valores[1]-$fecha_recibo_editar_li_valores[0]";
	// Actualizar datos del Recibo
	$sql2 = "UPDATE tab_recibos SET id_alquiler='$recibo_id_alquiler_editar',descripcion='$recibo_descripcion_editar',fecha_recibo_reg='$fecha_recibo_editar_1i',monto='$recibo_monto_editar',usuario='$recibo_usuario',fecha_usuario_reg=Current_Timestamp WHERE id_recibo='$id_recibo_editar'";
	$query2=$mysqli->query($sql2);
	$_SESSION["mensaje_recibo_editar"] = "Si";
	$_SESSION["mensaje_contenido_recibo_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=".$recibo_id_alquiler_editar."'</script>";
?>