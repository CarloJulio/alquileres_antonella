<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["usuario_crear_s_error"])){
        $_SESSION["usuario_crear_s_error"] = "No";
    }
    if (!isset($_SESSION["usuario_crear_error_mensaje"])){
        $_SESSION["usuario_crear_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["usuarios_crear_s_guardar"])){
        $_SESSION["usuarios_crear_s_guardar"] = "No";
    }
    if (!isset($_SESSION["usuario_usuario_crear"])){
        $_SESSION["usuario_usuario_crear"] = "";
    }
    if (!isset($_SESSION["usuario_clave_crear"])){
        $_SESSION["usuario_clave_crear"] = "";
    }
    if (!isset($_SESSION["usuario_nombres_crear"])){
        $_SESSION["usuario_nombres_crear"] = "";
    }
    if (!isset($_SESSION["usuario_apellidos_crear"])){
        $_SESSION["usuario_apellidos_crear"] = "";
    }
    if (!isset($_SESSION["usuario_rol_crear"])){
        $_SESSION["usuario_rol_crear"] = "";
    }
    // Rol usuario 
    $sqlsu="SELECT id_rol, rol FROM tab_roles ORDER BY rol";
    $querysu = $mysqli->query($sqlsu);
    $combobit3="<option value='seleccionar'>Seleccionar</option>";
    while ($rowsu=$querysu->fetch_assoc()) { 
        if($rowsu['rol'] == $_SESSION["usuario_rol_crear"]){
            $combobit3.=" <option value='".$rowsu['rol']."' selected='selected'>".$rowsu['rol']."</option>"; 
        }else{
            $combobit3.=" <option value='".$rowsu['rol']."'>".$rowsu['rol']."</option>"; 
        }
    }   
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
	<!-- Adaptable a diferentes tamaños de pantallas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Usuarios - Crear</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Usuarios - Crear</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="usuarios.php">Volver</a>
      <br/><br/>
      <div class="contenedor">
      <div class="contenedor texto-centrado">
		<font class="font3">Crear Usuario</font>	
	  </div> <!-- class="contenedor card texto-centrado" -->	
      <div style="overflow-x:auto"> 
      <form name="formulario_usuario" method="POST" action="usuarios_crear_validar_1.php" onsubmit="validar_formulario_usuario();return document.MM_returnValue">
        <table class="tab5" align="center">	
            <tr>   
            <td>    
                <label><b>Usuario</b></label>
           		<input class="input1" type="text" name="usuario_usuario_crear" maxlength="20" autofocus value="<?php echo $_SESSION["usuario_usuario_crear"] ?>">
            </td>
            </tr>
            <tr>   
            <td>                    
                <label><b>Contraseña</b></label>
                <input class="input1" type="text" name="usuario_clave_crear" maxlength="20" value="<?php echo $_SESSION["usuario_clave_crear"] ?>">
            </td>
            </tr>
            <tr>   
            <td>     
                <label><b>Nombre</b></label>
                <input class="input1" type="text" name="usuario_nombres_crear" maxlength="50" value="<?php echo $_SESSION["usuario_nombres_crear"] ?>">
            </td>
            </tr>
            <tr>   
            <td>     
                <label><b>Apellido</b></label>
                <input class="input1" type="text" name="usuario_apellidos_crear" maxlength="50" value="<?php echo $_SESSION["usuario_apellidos_crear"] ?>">
            </td>
            </tr>
            <tr>   
            <td>     
                <label><b>Rol</b></label>
                <select class="input1" name="usuario_rol_crear" ><?php echo $combobit3;?></select>
            </td>
            </tr>
            <tr>   
            <td>     
                <input class="boton" type="submit" value="Guardar">
            </td>
            </tr>
          </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	
        <br/>
      </div> <!-- class="contenedor -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<!-- Mensaje SweetAlert -->
    <?php
		$error = $_SESSION["usuario_crear_s_error"];
        $error_mensaje = $_SESSION["usuario_crear_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["usuario_crear_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>

    <?php
        }
    ?>   
    <!-- Mensaje SweetAlert -->
    <?php
    $usuario_crear_s_guardar = $_SESSION["usuarios_crear_s_guardar"];
    if($usuario_crear_s_guardar == "Si") {
        $_SESSION["usuarios_crear_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "usuarios_crear_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_usuario() { 
        var errors="";
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_usuario_crear'].value; 
        if (valor_vacio == "") {
            errors += '<font style="color:red">El Usuario no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_clave_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Contraseña no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_nombres_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Nombre no debe estar vacio</font>';
        }
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_apellidos_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Apellido no debe estar vacio</font>';
        } 
        var valor_seleccionar = document.forms['formulario_usuario'].elements['usuario_rol_crear'].value;
        if (errors == "" && valor_seleccionar == "seleccionar") {
            errors += '<font style="color:red">Debes Seleccionar el Rol</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>