<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Chequear si la sesión de usuario está vacio
	if (empty($_SESSION["usuario_usuario"])){
		header("Location:error1.php");
		exit();
	}
	// Se presionó el botón guardar
	if (isset($_POST["alquiler_id_bien_crear"])) {
		$_SESSION["alquiler_id_bien_crear"] = trim($_POST["alquiler_id_bien_crear"]);
		$_SESSION["alquiler_descripcion_crear"] = $_POST["alquiler_descripcion_crear"];
		$_SESSION["alquiler_fecha_crear"] = $_POST["alquiler_fecha_crear"];
		$_SESSION["alquiler_monto_crear"] = $_POST["alquiler_monto_crear"];
		// Chequear que el bien ya está alquilado
		$id_bien = trim($_POST["alquiler_id_bien_crear"]);
		$sql_id_bien = "SELECT id_bien FROM tab_alquileres WHERE (id_bien = '$id_bien')";
		$query_id_bien = $mysqli->query($sql_id_bien);
		$row_id_bien = $query_id_bien->fetch_assoc();
		$nro_registros_id_bien = $query_id_bien->num_rows;
		if($nro_registros_id_bien != 0) {
   			$_SESSION["alquiler_crear_s_error"] = "Si";
			$_SESSION["alquiler_crear_error_mensaje"] = "El Bien ya está alquilado";
			echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_crear.php'</script>";
			exit();	
		} 
		// Mensaje si desea guardar datos
		$_SESSION["alquiler_crear_s_guardar"] = "Si";
		echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_crear.php'</script>";
	}
?>