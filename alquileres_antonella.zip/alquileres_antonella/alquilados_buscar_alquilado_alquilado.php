<?php
  // Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
  // Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Mensaje de error
  if (!isset($_SESSION["mensaje_alquilado_error_editar"])){
    $_SESSION["mensaje_alquilado_error_editar"] = "";
  } 
  if (!isset($_SESSION["alquilados_buscar_alquilado_editar_s_guardar"])) {
      $_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "No";
  }  
	if (isset($_GET["nro_identidad"])) {
      $nro_indentidad = $_GET["nro_identidad"];
  }else{
    	echo "No se encuentra el Nro. Identidad del Alquilado";
    	exit();
  }
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Buscar Alquilado - Alquilado</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
    <!-- Mensajes Sweetalert -->
  	<link href="css/sweetalert2.min.css" rel="stylesheet">
  	<script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_alquilado, nro_identidad, nombre, apellido ";
	$sql .= "FROM tab_alquilados WHERE (nro_identidad = ".$nro_indentidad.") ";
	$sql .= "ORDER BY id_alquilado ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3><font class="font1">Alquilados</font></h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp<a href="alquilados_buscar_alquilado.php">Volver</a>
   	<div class="contenedor texto-centrado">
  		<h3><font class="font1">Alquilado</font></h3>	
  	</div> <!-- class="contenedor card texto-centrado" -->	
  	<?php
		if($nro_registros!=0) {
	?>
	<div style="overflow-x:auto">
		<table class="tab3" align="center">
  			<thead>
				<tr class="tr3">
	  				<th style="width:12%">Id Alquilado</th>
	  				<th style="width:15%">Nro. Identidad</th>
      				<th style="width:25%" class="contribuyente">Nombre</th>
      				<th style="width:25%">Apellido</th>
	  				<th style="width:23%">Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
	    ?>
	    		<tr class="tr3">
    				<td align = 'center'><?php echo $row['id_alquilado']; ?></td>
    				<td align = 'center'><?php echo $row['nro_identidad']; ?></td>
        			<td><?php echo $row['nombre']; ?></td>
        			<td><?php echo $row['apellido'] ?></td>
        			<td>
						<a href="alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=<?php echo $row['id_alquilado']; ?>">Alquileres</a>
						<a href="alquilados_buscar_alquilado_editar.php?id_alquilado=<?php echo $row['id_alquilado']; ?>">Editar</a>
        				<a href="#" onclick="eliminar_alquilado(<?php echo $row['id_alquilado']?>,<?php echo $row['nro_identidad'] ?>)">Eliminar</a>
        			</td>
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
		</table>
	</div>	
	<?php
		}else{ // if(!empty($resultados))
			echo "<div align='center'>";
			echo "<span style='color:red'><font class='font3'>No se encontró Nro. Identidad</font></span>";
			echo "</div>";
		} // if(!empty($resultados))
	?>	
    <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] == "Si") {
        $_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "No";
        $mensaje_alquilado_editar_contenido = $_SESSION["alquilados_buscar_alquilado_editar_s_guardar_contenido"];
?>
        <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Actualizados con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_alquilado_editar_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
        </script>
<?php
    }
?>
<?php
  	// Mensaje de error 
  	if($_SESSION["mensaje_alquilado_error_editar"]=="Si") {
        $_SESSION["mensaje_alquilado_error_editar"]="No";
        $mensaje_alquilado_contenido = $_SESSION["mensaje_contenido_alquilado_editar"];
?>
  		<script> 
        swal.fire({ title: 'Mensaje',
            text: 'No se pudo eliminar.',
            html: '<span style="color:red"><?php echo $mensaje_alquilado_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    	</script>
<?php
    }
?> 	
<script>
function eliminar_alquilado(id_alquilado,nro_identidad) {
   Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Alquilado:'+nro_identidad+'?',
        html: '<span style="color:red">¿Deseas eliminar el Alquilado:</span><span style="color:green">'+nro_identidad+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'alquilados_buscar_alquilado_eliminar_validar.php?id_alquilado='+id_alquilado+'&nro_identidad='+nro_identidad;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}
</script>
</body>
</html>