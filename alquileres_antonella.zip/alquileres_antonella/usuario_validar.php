<?php
	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Validar formulario con PHP
   	if (isset($_POST["usuario_usuario"])) {
		// Variables de sesiones
		$_SESSION["usuario_usuario"] = $_POST["usuario_usuario"];
		$_SESSION["usuario_password"] = $_POST["usuario_password"];
		// Variables para consultas sql
		$usuario_usuario = $_POST["usuario_usuario"];
		$usuario_password = $_POST["usuario_password"];
		// Chequear si el usuario existe
		$sql_2="SELECT usuario, clave FROM tab_usuarios WHERE (usuario = '".$usuario_usuario."')";
		$row_2 = $mysqli->query($sql_2);
		$fila_2 = $row_2->fetch_assoc();
		$_SESSION["usuario_incorrecto"]="No";
		$nro_registros_usuario_2 = $row_2->num_rows;
		if($nro_registros_usuario_2 == 0) {
			$_SESSION["usuario_incorrecto"]="Si";
			$_SESSION["usuario_incorrecto_mensaje"]="Usuario Incorrecto";
			echo "<script>location.href = 'index.php?usuario_usuario=$usuario_usuario'</script>";
			exit();
		}	
		// Chequear contraseña del usuario
		$sql="SELECT id_usuario, usuario, clave, nombre, rol FROM tab_usuarios WHERE (usuario = '".$usuario_usuario."') AND (clave = '".$usuario_password."')";
		$row = $mysqli->query($sql);
		$fila = $row->fetch_assoc();
		$nro_registros_usuario = $row->num_rows;
		if($nro_registros_usuario == 0) {
			$_SESSION["usuario_incorrecto"]="Si";
			$_SESSION["usuario_incorrecto_mensaje"]="Contraseña Incorrecta";
			echo "<script>location.href = 'index.php?usuario_usuario=$usuario_usuario'</script>";
			exit();
		}	
		// Cargar sistema
		$_SESSION["id_usuario"] = $fila['id_usuario'];
		$_SESSION["usuario_rol"] = $fila['rol'];
   		echo "<script>location.href = 'cargando.php'</script>";
	}
?>