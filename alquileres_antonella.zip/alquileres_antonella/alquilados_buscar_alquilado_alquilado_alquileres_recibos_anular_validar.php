<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del recibo
	$id_recibo = $_GET["id_recibo"];
	$condicion = $_GET["condicion"];
	$id_alquiler = $_SESSION["id_alquiler"];
	// tabla recibos
	if($condicion == "activar") {
		$sql_recibo = "UPDATE tab_recibos SET anulado='No'WHERE id_recibo='$id_recibo'";
		$_SESSION["mensaje_contenido_recibo_editar"] = "Recibo Activado con Éxito.";
	} else {
		$sql_recibo = "UPDATE tab_recibos SET anulado='Si'WHERE id_recibo='$id_recibo'";
		$_SESSION["mensaje_contenido_recibo_editar"] = "Recibo Anulado con Éxito.";
	}  
  	$query_recibo = $mysqli->query($sql_recibo);
	// Mensaje recibo 
	$_SESSION["mensaje_recibo_editar"] = "Si";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=".$id_alquiler."'</script>";
?>