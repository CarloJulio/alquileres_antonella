<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables de sesión
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_s_error"])){
        $_SESSION["alquilados_buscar_alquilado_editar_s_error"] = "No";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_error_mensaje"])){
        $_SESSION["alquilados_buscar_alquilado_editar_error_mensaje"] = "No";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_s_guardar"])){
        $_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"])){
        $_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"] = "";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_actual_nro_identidad"])){
        $_SESSION["alquilados_buscar_alquilado_editar_actual_nro_identidad"] = "";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_nombre"])){
        $_SESSION["alquilados_buscar_alquilado_editar_nombre"] = "";
    }
    if (!isset($_SESSION["alquilados_buscar_alquilado_editar_apellido"])){
        $_SESSION["alquilados_buscar_alquilado_editar_apellido"] = "";
    }
    // El Alquilado seleccionado
    if (isset($_GET["id_alquilado"])) {
        $id_alquilado = $_GET["id_alquilado"];
        $_SESSION["alquilados_buscar_alquilado_editar_id_alquilado"] = $_GET["id_alquilado"]; 
        // Buscar datos del Alquilado
        $sql_alquilado = "SELECT id_alquilado, nro_identidad, nombre, apellido FROM tab_alquilados WHERE (id_alquilado = $id_alquilado)";
        $query_alquilado = $mysqli->query($sql_alquilado);
        $row_alquilado = $query_alquilado->fetch_assoc();
        $nro_registros_alquilado = $query_alquilado->num_rows;
        if($nro_registros_alquilado != 0) {
            $nro_identidad = $row_alquilado['nro_identidad'];
            $nombre = $row_alquilado['nombre'];
            $apellido = $row_alquilado['apellido'];
        } else {
            echo "No se encuentra el Alquilado";
            exit();
        }
        // Iniciar variables de sesiones
        $_SESSION["alquilados_buscar_alquilado_editar_actual_nro_identidad"] = $nro_identidad;
        if(empty($_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"])) {
            $_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"] = $nro_identidad;
        }
        if(empty($_SESSION["alquilados_buscar_alquilado_editar_nombre"])) {
            $_SESSION["alquilados_buscar_alquilado_editar_nombre"] = $nombre;
        }
        if(empty($_SESSION["alquilados_buscar_alquilado_editar_apellido"])) {
            $_SESSION["alquilados_buscar_alquilado_editar_apellido"] = $apellido;
        }
    }else{
        echo "No se encuentra el id del Alquilado";
        exit();
    }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Buscar Alquilado - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Alquilados - Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="alquilados_buscar_alquilado_alquilado.php?nro_identidad=<?php echo $nro_identidad ?>">Volver</a>
      <br/><br/>
      <b>Id Alquilado:</b>
      <?php echo $id_alquilado ?>
      <br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Editar Alquilado</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
		<div style="overflow-x:auto"> 
		<form name="formulario_editar_alquilado" method="POST" action="alquilados_buscar_alquilado_editar_validar_1.php" onsubmit="validar_formulario_editar_alquilado();return document.MM_returnValue">
		    <table class="tab5" align="center">	
                <tr>   
                <td> 		
                    <label><b>Nro. Identidad</b></label>
           		    <input class="input" type="text" name="alquilados_buscar_alquilado_editar_nro_identidad" maxlength="15" autofocus value="<?php echo $_SESSION["alquilados_buscar_alquilado_editar_nro_identidad"] ?>">
                </td>
                </tr>
                <tr>   
                <td>  	
                    <label><b>Nombre</b></label>
                    <input class="input" type="text" name="alquilados_buscar_alquilado_editar_nombre" maxlength="50" value="<?php echo $_SESSION["alquilados_buscar_alquilado_editar_nombre"] ?>">
                </td>
                </tr>
                <tr>   
                <td>      
                    <label><b>Apellido</b></label>
                    <input class="input" type="text" name="alquilados_buscar_alquilado_editar_apellido" maxlength="50" value="<?php echo $_SESSION["alquilados_buscar_alquilado_editar_apellido"] ?>">
                </td>
                </tr>
                <tr>   
                <td>      
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div>  <!-- <div style="overflow-x:auto">  -->
        <br/>
	  </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
		$error = $_SESSION["alquilados_buscar_alquilado_editar_s_error"];
        $error_mensaje = $_SESSION["alquilados_buscar_alquilado_editar_error_mensaje"];
        if ($error=="Si") { // Si el campo esta vacío
            $_SESSION["alquilados_buscar_alquilado_editar_s_error"] = "No";
    ?>
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $error_mensaje ?>',
                    html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });
            </script>
    <?php
        }
    ?>   
    <?php
    $usuario_editar_s_guardar = $_SESSION["alquilados_buscar_alquilado_editar_s_guardar"];
    if($usuario_editar_s_guardar == "Si") {
        $_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "alquilados_buscar_alquilado_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario alquilado con javascript
    function validar_formulario_editar_alquilado() { 
        var errors="";
        var nro_indentidad = document.forms['formulario_editar_alquilado'].elements['alquilados_buscar_alquilado_editar_nro_identidad'].value; 
        if (nro_indentidad == "") {
            errors += '<font style="color:red">El Nro. Identidad no debe estar vacio</font>';
        } 
        // El nro_indentidad no es nulo
        if (errors == "") {
            // Chequear si el nro_indentidad es un número 
            if(isNaN(nro_indentidad)) {
                errors += '<font style="color:red">El Nro. de identidad <br/> debe ser un número</font>';
            } else {
                // Chequear si el nro_indentidad es un número entero
                nro_indentidad = parseFloat(nro_indentidad);
                if(Number.isInteger(nro_indentidad)){
                    // errors == "", no hace nada    
                } else {
                    errors += '<font style="color:red">El Nro. de identidad <br/> debe ser un número entero</font>';
                }
            }
        }
        if (errors == "") {
            // Chequear si el nombre es nulo
            var nombre = document.forms['formulario_editar_alquilado'].elements['alquilados_buscar_alquilado_editar_nombre'].value; 
            if (nombre == "") {
                errors += '<font style="color:red">El Nombre <br/> no debe estar vacio</font>';
            } 
        }
        if (errors == "") {
            // Chequear si el apellido es nulo
            var nombre = document.forms['formulario_editar_alquilado'].elements['alquilados_buscar_alquilado_editar_apellido'].value; 
            if (nombre == "") {
                errors += '<font style="color:red">El Apellido <br/> no debe estar vacio</font>';
            } 
        }
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>