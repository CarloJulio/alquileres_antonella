<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  if (!isset($_SESSION["mensaje_usuario_editar"])){
      $_SESSION["mensaje_usuario_editar"] = "";
  } 
  // Iniciar variables de sesiones
  if (!isset($_SESSION["usuario_editar_s_error"])){
    $_SESSION["usuario_editar_s_error"] = "";  
  } 
  if (!isset($_SESSION["usuario_editar_error_mensaje"])){
    $_SESSION["usuario_editar_error_mensaje"] = "";  
  } 
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
  <!-- Caracteres en español -->
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Usuarios</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_usuario, usuario, clave, rol ";
	$sql .= "FROM tab_usuarios ";
	$sql .= "ORDER BY id_usuario ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Usuarios</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <div class="contenedor texto-centrado">
  	<h3><font class="font1">Usuarios</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
 	<div style="overflow-x:auto">
    <table class="tab1" align="center">
         <thead>
        <tr class="tr1">
          <td>
            <a href="usuarios_crear.php">Crear</a>&nbsp&nbsp  
          </td>
        </tr>  
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr1">
	  				<th style="width:5%">Id</th>
	  				<th style="width:20%">Usuario</th>
      			<th style="width:20%" class="contribuyente">Contraseña</th>
      			<th style="width:20%">Rol</th>
      			<th >Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
	    ?>
	    		<tr class="tr1">
    				<td align = "center"><?php echo $row['id_usuario']; ?></td>
    				<td><?php echo $row['usuario'] ?></td>
        		<td><?php echo $row['clave']; ?></td>
        		<td><?php echo $row['rol'] ?></td>
        		<td align = "center">
        				<a href="usuarios_editar.php?id_usuario=<?php echo $row['id_usuario']?>">Editar</a>
                <a href="#" onclick="eliminar_usuario(<?php echo $row['id_usuario']?>,'<?php echo $row['usuario'] ?>')">Eliminar</a>
                <a href="usuarios_vista.php?id_usuario=<?php echo $row['id_usuario']?>">Vista</a>
            </td>
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr1'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Usuarios</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_usuario_editar"] == "Si"){
        $_SESSION["mensaje_usuario_editar"]="No";
        $mensaje_rentas_contenido = $_SESSION["mensaje_contenido_usuario_editar"];
    ?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_rentas_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<?php
    $error = $_SESSION["usuario_editar_s_error"];
    $error_mensaje = $_SESSION["usuario_editar_error_mensaje"];
    if ($error=="Si") { // Si el campo esta vacío
      $_SESSION["usuario_editar_s_error"] = "No";
?>
      <script>
        Swal.fire({
          title: 'Mensaje',
          text: '<?php echo $error_mensaje ?>',
          html: '<span style="color:red"><?php echo $error_mensaje ?></span>',
          confirmButtonText: 'Aceptar',
          allowOutsideClick: false
        });
      </script>
<?php
    }
?>   
<script>
function eliminar_usuario(id_usuario, usuario) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Usuario:'+usuario+'?',
        html: '<span style="color:red">¿Deseas eliminar el Usuario:</span><span style="color:green">'+usuario+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'usuarios_eliminar_validar.php?id_usuario='+id_usuario+'&usuario='+usuario;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}    
</script>
</body>
</html>