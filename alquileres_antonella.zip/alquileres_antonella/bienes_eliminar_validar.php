<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	$id_bien = $_GET["id_bien"];
	// tabla de aquileres  
	$sql_alquiler = "SELECT id_bien FROM tab_alquileres WHERE (id_bien = $id_bien)";
	$query_alquiler = $mysqli->query($sql_alquiler);  
	$nro_registros = $query_alquiler->num_rows;  
	// Si el bien tiene alquileres  
	if($nro_registros!=0) {  
		$_SESSION["mensaje_bien_error_editar"] = "Si";
		$_SESSION["mensaje_bien_editar"] = "No";
		$_SESSION["mensaje_contenido_bien_editar"] = "Bien no se pudo Eliminar, tiene alquileres";
	} else {  	
		// tabla bienes
		$sql_bien = "DELETE FROM tab_bienes WHERE (id_bien = ".$id_bien.")";
  		$query_bien = $mysqli->query($sql_bien);
		// Mensaje Usuario eliminado
		$_SESSION["mensaje_bien_editar"] = "Si";
		$_SESSION["mensaje_bien_error_editar"] = "No";
		$_SESSION["mensaje_contenido_bien_editar"] = "Bien Eliminado con Éxito.";
	}	
	echo "<script>location.href = 'bienes.php'</script>";
?>