<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Se presionó el botón guardar
	if (isset($_POST["usuario_usuario_crear"])) {
		$_SESSION["usuario_usuario_crear"] = trim($_POST["usuario_usuario_crear"]);
		$_SESSION["usuario_clave_crear"] = $_POST["usuario_clave_crear"];
		$_SESSION["usuario_rol_crear"] = $_POST["usuario_rol_crear"];
		$_SESSION["usuario_nombres_crear"] = $_POST["usuario_nombres_crear"];
		$_SESSION["usuario_apellidos_crear"] = $_POST["usuario_apellidos_crear"];
		// Chequear que el Usuario si existe
		$usuario = trim($_POST["usuario_usuario_crear"]);
		$sql_usuario = "SELECT usuario FROM tab_usuarios WHERE (usuario = '$usuario')";
		$query_usuario = $mysqli->query($sql_usuario);
		$row_usuario = $query_usuario->fetch_assoc();
		$nro_registros_usuario = $query_usuario->num_rows;
		if($nro_registros_usuario != 0) {
   			$_SESSION["usuario_crear_s_error"] = "Si";
			$_SESSION["usuario_crear_error_mensaje"] = "El Usuario ya existe";
			echo "<script>location.href = 'usuarios_crear.php'</script>";
			exit();	
		} 
		// Mensaje si desea guardar datos
		$_SESSION["usuarios_crear_s_guardar"] = "Si";
		echo "<script>location.href = 'usuarios_crear.php'</script>";
	} // if (isset($_POST["usuario_usuario_crear"]))
?>