<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
    header("Location:error1.php");
    exit();
  }
  // Mensaje de dato guardado
  if (!isset($_SESSION["mensaje_bien_editar"])){
      $_SESSION["mensaje_bien_editar"] = "";
  } 
  // fecha actual, formato español
  $sql = "SELECT current_date";
  $row = $mysqli->query($sql);
  $consultaf = $row->fetch_assoc();
  $fechadelmysql = date_create($consultaf['current_date']);
  $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
  $_SESSION['fecha_hoy'] = $fechadelmysql;
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquilados</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_alquilado, nro_identidad, nombre, apellido ";
	$sql .= "FROM tab_alquilados ";
	$sql .= "ORDER BY id_alquilado ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Alquilados</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <a href="menu_alquilados.php">Volver</a>
  <div class="contenedor texto-centrado">
    <h3><font class="font1">Alquilados</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
  <div style="overflow-x:auto">
    <table class="tab2" align="center">
         <thead>
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr2">
	  				<th style="width:5%">Id</th>
	  				<th style="width:15%">Nro. Identidad</th>
      			<th style="width:40%">Nombre</th>
      			<th style="width:40%">Apellido</th>
      	</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
      ?>
	    		<tr class="tr2">
    				<td align = "center"><?php echo $row['id_alquilado']; ?></td>
    				<td><?php echo $row['nro_identidad'] ?></td>
        		<td><?php echo $row['nombre']; ?></td>
        		<td><?php echo $row['apellido'] ?></td>
        	</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr2'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Alquilados</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_bien_editar"] == "Si"){
        $_SESSION["mensaje_bien_editar"]="No";
        $mensaje_bien_contenido = $_SESSION["mensaje_contenido_bien_editar"];
    ?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_bien_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<script>
function eliminar_bien(id_bien) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Bien de Id:'+id_bien+'?',
        html: '<span style="color:red">¿Deseas eliminar el Bien de Id:</span><span style="color:green">'+id_bien+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'bienes_eliminar_validar.php?id_bien='+id_bien;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}      
</script>
</body>
</html>