<?php
	// Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la identidad existe
	if (isset($_POST["alquilados_buscar_alquilado_crear_nro_identidad"])) {
		$alquilados_buscar_alquilado_crear_nro_identidad = trim($_POST["alquilados_buscar_alquilado_crear_nro_identidad"]);
		$_SESSION["alquilados_buscar_alquilado_crear_nro_identidad"] = trim($_POST["alquilados_buscar_alquilado_crear_nro_identidad"]);
		$sql="SELECT id_alquilado, nro_identidad, nombre, apellido FROM tab_alquilados WHERE (nro_identidad = ".$alquilados_buscar_alquilado_crear_nro_identidad.")";
		$row = $mysqli->query($sql);
		$fila = $row->fetch_assoc();
		$nro_registros=$row->num_rows;
		if($nro_registros != 0){ // No debe existir el nro. identidad
			$_SESSION["alquilados_buscar_alquilado_crear_nombre"] = $_POST["alquilados_buscar_alquilado_crear_nombre"];
			$_SESSION["alquilados_buscar_alquilado_crear_apellido"] = $_POST["alquilados_buscar_alquilado_crear_apellido"];		    		
			$_SESSION["alquilados_buscar_alquilado_crear_existe"] = "Si";
			$_SESSION["alquilados_buscar_alquilado_crear_existe_mensaje"] = "Nro. de Identidad Existe";
			echo "<script>location.href = 'alquilados_buscar_alquilado_crear.php'</script>";
			exit();
		} 
	}	
	// Mesaje guardar datos
	$_SESSION["alquilados_buscar_alquilado_buscar"] = $_POST["alquilados_buscar_alquilado_crear_nro_identidad"];
	$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"] = $_POST["alquilados_buscar_alquilado_crear_nro_identidad"];
	$_SESSION["alquilados_buscar_alquilado_crear_nombre"] = $_POST["alquilados_buscar_alquilado_crear_nombre"];
	$_SESSION["alquilados_buscar_alquilado_crear_apellido"] = $_POST["alquilados_buscar_alquilado_crear_apellido"];
	$_SESSION["alquilados_buscar_alquilado_crear_s_guardar"] = "Si";
	if($_SESSION["alquilados_buscar_alquilado_crear_s_guardar"] == "Si") {
		echo "<script>location.href = 'alquilados_buscar_alquilado_crear.php'</script>";
		exit();	
	}
?>