<?php
	// Conexión a la base de datos Alquileres Antonella
  	require("conexion/conexion.php");
	// Iniciar sesión del Usuario  
	session_start();
	// Chequear si la sesión de usuario esta cerrado
  	if (!isset($_SESSION["usuario_usuario"])){
    	header("Location:error1.php");
    	exit();
  	} 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Alquilado  
  	$id_alquilado = $_GET["id_alquilado"];
	$nro_identidad = $_GET["nro_identidad"];
	// Tabla de alquileres
	$sql_alquileres = "SELECT id_alquilado FROM tab_alquileres WHERE (id_alquilado = $id_alquilado)";
	$query_alquileres = $mysqli->query($sql_alquileres);  
	$nro_registros = $query_alquileres->num_rows;        
	// Si el alquiler tiene alquileres  
	if($nro_registros!=0) {  
		$_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "No";
		$_SESSION["mensaje_alquilado_error_editar"] = "Si";
		$_SESSION["mensaje_contenido_alquilado_editar"] = "Aquilado no se pudo Eliminar, tiene alquileres";
	}  else {    
		// tabla alquilados
		$sql_alquilado = "DELETE FROM tab_alquilados WHERE (id_alquilado = ".$id_alquilado.")";
  		$query_alquilado = $mysqli->query($sql_alquilado);
		// Mensaje Alquilado eliminado
		$_SESSION["alquilados_buscar_alquilado_editar_s_guardar"] = "Si";
		$_SESSION["alquilados_buscar_alquilado_editar_s_guardar_contenido"] = "Alquilado Eliminado con Éxito.";
	}	
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado.php?nro_identidad=$nro_identidad';</script>";
?>