<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Datos del Alquiler
	$id_alquiler = $_SESSION["id_alquiler_editar_alquileres"];
	$id_alquilado = $_SESSION["id_alquilado"];
	$id_bien_alquiler = $_SESSION["alquiler_bien_editar"];
	$alquiler_descripcion = $_SESSION["alquiler_descripcion_editar"];
	$alquiler_fecha = $_SESSION["alquiler_fecha_editar"];
	$alquiler_monto = $_SESSION["alquiler_monto_editar"];
 	$alquiler_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_alquiler = $alquiler_fecha;
    $fecha_alquiler = trim($fecha_alquiler);
    $fecha_alquiler_li_valores = explode('/', $fecha_alquiler);
    $fecha_alquiler_1i = "$fecha_alquiler_li_valores[2]-$fecha_alquiler_li_valores[1]-$fecha_alquiler_li_valores[0]";
	// Actualizar datos del Bien
	$sql2 = "UPDATE tab_alquileres SET id_bien='$id_bien_alquiler',descripcion='$alquiler_descripcion',fecha_alquiler_reg='$fecha_alquiler_1i',monto='$alquiler_monto',usuario='$alquiler_usuario',fecha_usuario_reg=Current_Timestamp WHERE id_alquiler='$id_alquiler'";
	$query2=$mysqli->query($sql2);
	$_SESSION["mensaje_alquiler_editar"] = "Si";
	$_SESSION["mensaje_contenido_alquiler_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=".$id_alquilado."'</script>";
?>