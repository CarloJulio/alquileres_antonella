<?php
	require("conexion/conexion.php");
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	$id_usuario = $_SESSION["id_usuario_editar_herramientas"];
	$usuario_usuario = $_SESSION["usuario_usuario_editar"];
	$usuario_clave = $_SESSION["usuario_clave_editar"];
	$usuario_nombres = $_SESSION["usuario_nombres_editar"];
	$usuario_apellidos = $_SESSION["usuario_apellidos_editar"];
	$usuario_rol = $_SESSION["usuario_rol_editar"];
	// Actualizar datos del Usuario
	$sql2 = "UPDATE tab_usuarios SET usuario='$usuario_usuario',clave='$usuario_clave',nombre='$usuario_nombres',apellido='$usuario_apellidos',rol='$usuario_rol' WHERE id_usuario='$id_usuario'";
	$query2=$mysqli->query($sql2);
	$_SESSION["mensaje_usuario_editar"] = "Si";
	$_SESSION["mensaje_contenido_usuario_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'usuarios.php'</script>";
?>