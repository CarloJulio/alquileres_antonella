-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-09-2024 a las 02:27:20
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alquileres_antonella`
--

CREATE DATABASE IF NOT EXISTS `alquileres_antonella` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `alquileres_antonella`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_alquilados`
--

CREATE TABLE `tab_alquilados` (
  `id_alquilado` int(2) NOT NULL,
  `nro_identidad` int(11) NOT NULL,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `fecha_usuario_reg` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_alquilados`
--

INSERT INTO `tab_alquilados` (`id_alquilado`, `nro_identidad`, `nombre`, `apellido`, `usuario`, `fecha_usuario_reg`) VALUES
(1, 12566784, 'Antonio José', 'Navarro', 'Mini', '2022-11-18 19:08:46'),
(2, 15244687, 'María Alejandra', 'Mora', 'Mini', '2022-11-18 19:09:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_alquileres`
--

CREATE TABLE `tab_alquileres` (
  `id_alquiler` int(11) NOT NULL,
  `id_alquilado` int(11) NOT NULL,
  `id_bien` varchar(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fecha_alquiler_reg` date NOT NULL,
  `monto` double(15,2) NOT NULL,
  `usuario` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_usuario_reg` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_alquileres`
--

INSERT INTO `tab_alquileres` (`id_alquiler`, `id_alquilado`, `id_bien`, `descripcion`, `fecha_alquiler_reg`, `monto`, `usuario`, `fecha_usuario_reg`) VALUES
(1, 1, '1', 'Contrato Nro. 1, pago a final del mes', '2022-11-01', 100.00, 'Mini', '2022-11-18 20:44:39'),
(2, 2, '2', 'Contrato Nro. 2, pago alquiler al final del mes', '2022-11-18', 120.00, 'Mini', '2022-11-18 20:57:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_bienes`
--

CREATE TABLE `tab_bienes` (
  `id_bien` int(11) NOT NULL,
  `bien` varchar(20) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `fecha_bien_reg` date NOT NULL,
  `usuario` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_usuario_reg` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_bienes`
--

INSERT INTO `tab_bienes` (`id_bien`, `bien`, `descripcion`, `direccion`, `fecha_bien_reg`, `usuario`, `fecha_usuario_reg`) VALUES
(1, 'Casa', 'Casa 1: 4 cuartos, sala comedor, cocina, lavadero, 2 baños, patio, garage ', 'Carrera 4ta., nro. 3-22, Sabaneta, Tovar', '2022-11-18', 'Mini', '2022-12-12 20:23:54'),
(2, 'Casa', 'Casa 2: 2 cuartos, sala comerdor, cocina, lavadero, 1 baño, patio', 'Carrera 4ta., nro. 50-09, El Llano, Tovar', '2022-11-18', 'Mini', '2022-12-12 20:24:05'),
(3, 'Apartamento', '1 cuarto, sala comedor, 1 baño, cocina, lavadero', 'Edificio Mora, Nro. 1-2, calle 3, El Corozo, Tovar ', '2022-11-18', 'Mini', '2022-11-18 20:40:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_bienes_tipos`
--

CREATE TABLE `tab_bienes_tipos` (
  `id_bien_tipo` int(11) NOT NULL,
  `bien_tipo` varchar(20) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `fecha_usuario_reg` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_bienes_tipos`
--

INSERT INTO `tab_bienes_tipos` (`id_bien_tipo`, `bien_tipo`, `usuario`, `fecha_usuario_reg`) VALUES
(1, 'Casa', 'Mini', '2022-11-07 21:24:50'),
(2, 'Apartamento', 'Mini', '2022-11-07 21:24:50'),
(3, 'Local', 'Mini', '2022-11-07 21:24:50'),
(4, 'Garage', 'Mini', '2022-11-07 21:24:50'),
(5, 'Galpón', 'nks', '2022-11-18 18:59:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_recibos`
--

CREATE TABLE `tab_recibos` (
  `id_recibo` int(11) NOT NULL,
  `id_alquiler` varchar(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fecha_recibo_reg` date NOT NULL,
  `monto` double(15,2) NOT NULL,
  `anulado` varchar(2) NOT NULL DEFAULT 'No',
  `usuario` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `fecha_usuario_reg` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_recibos`
--

INSERT INTO `tab_recibos` (`id_recibo`, `id_alquiler`, `descripcion`, `fecha_recibo_reg`, `monto`, `anulado`, `usuario`, `fecha_usuario_reg`) VALUES
(1, '1', 'Pago alquiler mes de Noviembre', '2022-11-30', 100.00, 'No', 'Mini', '2022-11-18 20:55:40'),
(2, '2', 'Pago alquiler mes de Noviembre', '2022-11-30', 120.00, 'No', 'Mini', '2022-11-18 20:58:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_roles`
--

CREATE TABLE `tab_roles` (
  `id_rol` int(11) NOT NULL,
  `rol` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_roles`
--

INSERT INTO `tab_roles` (`id_rol`, `rol`) VALUES
(1, 'Administrador'),
(2, 'Empleado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tab_usuarios`
--

CREATE TABLE `tab_usuarios` (
  `id_usuario` int(2) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `clave` varchar(20) NOT NULL,
  `nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `rol` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tab_usuarios`
--

INSERT INTO `tab_usuarios` (`id_usuario`, `usuario`, `clave`, `nombre`, `apellido`, `rol`) VALUES
(1, 'Mini', '12345', 'Mini Sistemas', 'CJCV', 'Administrador'),
(2, 'Keyla', '12345', 'Keyla', 'Obelmejías', 'Empleado');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tab_alquilados`
--
ALTER TABLE `tab_alquilados`
  ADD PRIMARY KEY (`id_alquilado`),
  ADD UNIQUE KEY `id_usuario` (`id_alquilado`);

--
-- Indices de la tabla `tab_alquileres`
--
ALTER TABLE `tab_alquileres`
  ADD PRIMARY KEY (`id_alquiler`);

--
-- Indices de la tabla `tab_bienes`
--
ALTER TABLE `tab_bienes`
  ADD PRIMARY KEY (`id_bien`);

--
-- Indices de la tabla `tab_bienes_tipos`
--
ALTER TABLE `tab_bienes_tipos`
  ADD PRIMARY KEY (`id_bien_tipo`);

--
-- Indices de la tabla `tab_recibos`
--
ALTER TABLE `tab_recibos`
  ADD PRIMARY KEY (`id_recibo`);

--
-- Indices de la tabla `tab_roles`
--
ALTER TABLE `tab_roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `tab_usuarios`
--
ALTER TABLE `tab_usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tab_alquilados`
--
ALTER TABLE `tab_alquilados`
  MODIFY `id_alquilado` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tab_alquileres`
--
ALTER TABLE `tab_alquileres`
  MODIFY `id_alquiler` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tab_bienes`
--
ALTER TABLE `tab_bienes`
  MODIFY `id_bien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tab_bienes_tipos`
--
ALTER TABLE `tab_bienes_tipos`
  MODIFY `id_bien_tipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tab_recibos`
--
ALTER TABLE `tab_recibos`
  MODIFY `id_recibo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tab_roles`
--
ALTER TABLE `tab_roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tab_usuarios`
--
ALTER TABLE `tab_usuarios`
  MODIFY `id_usuario` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
