<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Alquilado
	$id_alquilado = $_SESSION["id_alquilado"];
	$alquiler_id_bien = $_SESSION["alquiler_id_bien_crear"];
	$alquiler_descripcion = $_SESSION["alquiler_descripcion_crear"];
	$alquiler_fecha = $_SESSION["alquiler_fecha_crear"];
	$alquiler_monto = $_SESSION["alquiler_monto_crear"];
	$alquiler_usuario = $_SESSION["usuario_usuario"];
	// Pasar fecha a formato inglés
    $fecha_alquiler = $alquiler_fecha;
    $fecha_alquiler = trim($fecha_alquiler);
    $fecha_alquiler_li_valores = explode('/', $fecha_alquiler);
    $fecha_alquiler_1i = "$fecha_alquiler_li_valores[2]-$fecha_alquiler_li_valores[1]-$fecha_alquiler_li_valores[0]";
	// Guardar nuevo Alquiler	
	$sql="INSERT INTO tab_alquileres (id_alquilado, id_bien, descripcion, fecha_alquiler_reg, monto, usuario, fecha_usuario_reg) ";
	$sql.="VALUES ('$id_alquilado','$alquiler_id_bien','$alquiler_descripcion','$fecha_alquiler_1i','$alquiler_monto','$alquiler_usuario',Current_Timestamp)";
    $query=$mysqli->query($sql);
    /* Destruir las variables la variables de sesiones
    de los datos del Bien nuevo */ 
    unset($_SESSION["alquiler_id_bien_crear"]);
	unset($_SESSION["alquiler_descripcion_crear"]);
    unset($_SESSION["alquiler_fecha_crear"]);
	unset($_SESSION["alquiler_monto_crear"]);
	// Mensaje de datos guardado
    $_SESSION["mensaje_alquiler_editar"] = "Si";
	$_SESSION["mensaje_contenido_alquiler_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'alquilados_buscar_alquilado_alquilado_alquileres.php?id_alquilado=".$id_alquilado."'</script>";
?>