<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Mensaje de dato guardado
  if (!isset($_SESSION["mensaje_bien_editar"])){
      $_SESSION["mensaje_bien_editar"] = "";
  } 
  // Mensaje de error
  if (!isset($_SESSION["mensaje_bien_error_editar"])){
    $_SESSION["mensaje_bien_error_editar"] = "";
  } 
  // fecha actual, formato español
  $sql = "SELECT current_date";
  $row = $mysqli->query($sql);
  $consultaf = $row->fetch_assoc();
  $fechadelmysql = date_create($consultaf['current_date']);
  $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
  $_SESSION['fecha_hoy'] = $fechadelmysql;
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_bien, bien, descripcion, fecha_bien_reg ";
	$sql .= "FROM tab_bienes ";
	$sql .= "ORDER BY id_bien ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Bienes</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <a href="menu_bienes.php">Volver</a>&nbsp&nbsp
  <div class="contenedor texto-centrado">
    <h3><font class="font1">Bienes</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
  <div style="overflow-x:auto">
    <table class="tab2" align="center">
         <thead>
        <tr class="tr2">
          <td>
            <a href="bienes_crear.php">Crear</a>&nbsp&nbsp  
          </td>
        </tr>  
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr2">
	  				<th style="width:5%">Id</th>
	  				<th style="width:20%">Bien</th>
      			<th style="width:40%">Descripción</th>
      			<th style="width:12%">Fecha</th>
      			<th >Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
         // Pasar fecha a formato español
          $fecha_bien = $row['fecha_bien_reg'];
          $fecha_bien = trim($fecha_bien);
          $fecha_bien_li_valores = explode('-', $fecha_bien);
          $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
      ?>
	    		<tr class="tr2">
    				<td align = "center"><?php echo $row['id_bien']; ?></td>
    				<td><?php echo $row['bien'] ?></td>
        		<td><?php echo $row['descripcion']; ?></td>
        		<td align = 'center'><?php echo $fecha_bien_1i ?></td>
        		<td align = "center">
        				<a href="bienes_editar.php?id_bien=<?php echo $row['id_bien']?>">Editar</a>
                <a href="#" onclick="eliminar_bien(<?php echo $row['id_bien']?>)">Eliminar</a>
                <a href="bienes_vista.php?id_bien=<?php echo $row['id_bien']?>">Vista</a>
            </td>
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr2'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Bienes</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_bien_editar"]=="Si"){
        $_SESSION["mensaje_bien_editar"]="No";
        $mensaje_bien_contenido = $_SESSION["mensaje_contenido_bien_editar"];
?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_bien_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<?php
    // Mensaje de error 
    if($_SESSION["mensaje_bien_error_editar"]=="Si"){
        $_SESSION["mensaje_bien_error_editar"]="No";
        $mensaje_bien_contenido = $_SESSION["mensaje_contenido_bien_editar"];
?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'No se pudo eliminar.',
            html: '<span style="color:red"><?php echo $mensaje_bien_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<script>
function eliminar_bien(id_bien) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Bien de Id:'+id_bien+'?',
        html: '<span style="color:red">¿Deseas eliminar el Bien de Id:</span><span style="color:green">'+id_bien+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'bienes_eliminar_validar.php?id_bien='+id_bien;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}      
</script>
</body>
</html>