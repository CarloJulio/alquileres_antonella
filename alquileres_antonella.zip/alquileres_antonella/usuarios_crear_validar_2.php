<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Usuario
	$usuario = $_SESSION["usuario_usuario_crear"];
	$usuario_clave = $_SESSION["usuario_clave_crear"];
	$usuario_nombre = $_SESSION["usuario_nombres_crear"];
	$usuario_apellido = $_SESSION["usuario_apellidos_crear"];
	$usuario_rol = $_SESSION["usuario_rol_crear"];
	// Guardar nuevo Usuario	
	$sql="INSERT INTO tab_usuarios (usuario, clave, nombre, apellido, rol) ";
	$sql.="VALUES ('$usuario','$usuario_clave','$usuario_nombre','$usuario_apellido','$usuario_rol')";
    $query=$mysqli->query($sql);
    /* Destruir las variables la variables de sesiones
    de los datos del Usuario nuevo */ 
    unset($_SESSION["usuario_usuario_crear"]);
	unset($_SESSION["usuario_clave_crear"]);
	unset($_SESSION["usuario_nombres_crear"]);
	unset($_SESSION["usuario_apellidos_crear"]);
	unset($_SESSION["usuario_rol_crear"]);
    // Mensaje de dato guardado
    $_SESSION["mensaje_usuario_editar"] = "Si";
	$_SESSION["mensaje_contenido_usuario_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'usuarios.php'</script>";
	exit();	
?>