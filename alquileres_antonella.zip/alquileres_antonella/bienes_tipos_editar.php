<?php
    // Conectar a la base de datos Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Si la variable de sesiones si no está definido entonces definirlo
    if (!isset($_SESSION["bien_tipo_editar_s_guardar"])){
        $_SESSION["bien_tipo_editar_s_guardar"] = "No";
    }
    if (!isset($_SESSION["bien_tipo_editar"])){
        $_SESSION["bien_tipo_editar"] = "";
    }
    // El Bien seleccionado para editar
    if (isset($_GET["id_bien_tipo"])) {
        $id_bien = $_GET["id_bien_tipo"];  
        $_SESSION["id_bien_tipo_editar"] = $_GET["id_bien_tipo"];  
        $sql_bien = "SELECT id_bien_tipo, bien_tipo FROM tab_bienes_tipos WHERE (id_bien_tipo = $id_bien)";
        $query_bien = $mysqli->query($sql_bien);
        $row_bien = $query_bien->fetch_assoc();
        $nro_registros_bien = $query_bien->num_rows;
        if($nro_registros_bien != 0) {
            $bien_tipo = $row_bien['bien_tipo'];
            // Iniciar variables de sesiones
            $_SESSION["bien_tipo_editar"] = $bien_tipo;
        } else {
            echo "No se encuentra el Bien Tipo";
            exit();
        }
    } // if (isset($_GET["id_bien_tipo"]))
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes Tipos - Editar</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Bienes Tipos - Editar</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="bienes_tipos.php">Volver</a>
      <br/><br/>
      <b>Id Bien Tipo:</b>
      <?php echo $_SESSION["id_bien_tipo_editar"] ?>
      <br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Editar Bien Tipo</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
        <div style="overflow-x:auto"> 
		<form name="formulario_bien_tipo" method="POST" action="bienes_tipos_editar_validar_1.php" onsubmit="validar_formulario_bien_tipo();return document.MM_returnValue">
            <table class="tab10" align="center">	
                <tr>   
                <td> 
                    <label><b>Bien Tipo</b></label>
                    <input class="input" type="text" name="bien_tipo_editar" maxlength="20" value="<?php echo $_SESSION["bien_tipo_editar"] ?>">
                </td>
                </tr>
                <tr>   
                <td> 
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        </div> <!-- <div style="overflow-x:auto"> -->	  
        <br/>
      </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
    <?php
	$bien_tipo_editar_s_guardar = $_SESSION["bien_tipo_editar_s_guardar"];
    if($bien_tipo_editar_s_guardar == "Si") {
        $_SESSION["bien_tipo_editar_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "bienes_tipos_editar_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
    }
    ?>
    <script>
    // Validar formulario usuario con javascript
    function validar_formulario_bien_tipo() { 
        var errors="";
        var valor_vacio = document.forms['formulario_bien_tipo'].elements['bien_tipo_editar'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">Bien Tipo no debe estar vacio</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>