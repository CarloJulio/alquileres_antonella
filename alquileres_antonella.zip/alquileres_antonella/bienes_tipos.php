<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
    header("Location:error1.php");
    exit();
  }
  // Mensaje de dato guardado
  if (!isset($_SESSION["mensaje_bien_tipo_editar"])){
    $_SESSION["mensaje_bien_tipo_editar"] = "";
  } 
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Bienes Tipos</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_bien_tipo, bien_tipo ";
	$sql .= "FROM tab_bienes_tipos ";
	$sql .= "ORDER BY id_bien_tipo ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Bienes Tipos</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <a href="menu_bienes.php">Volver</a>&nbsp&nbsp
  <div class="contenedor texto-centrado">
    <h3><font class="font1">Bienes Tipos</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
  <div style="overflow-x:auto">
    <table class="tab9" align="center">
         <thead>
        <tr class="tr9">
          <td>
            <a href="bienes_tipos_crear.php">Crear</a>&nbsp&nbsp  
          </td>
        </tr>  
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr9">
	  				<th style="width:5%">Id</th>
	  				<th style="width:50%">Bien Tipo</th>
      			<th >Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
      ?>
	    		<tr class="tr9">
    				<td align = "center"><?php echo $row['id_bien_tipo']; ?></td>
    				<td><?php echo $row['bien_tipo'] ?></td>
        		<td align = "center">
        				<a href="bienes_tipos_editar.php?id_bien_tipo=<?php echo $row['id_bien_tipo']?>">Editar</a>
                <a href="#" onclick="eliminar_bien_tipo(<?php echo $row['id_bien_tipo']?>)">Eliminar</a>
            </td>
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr2'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Bienes</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_bien_tipo_editar"] == "Si"){
        $_SESSION["mensaje_bien_tipo_editar"]="No";
        $mensaje_bien_contenido = $_SESSION["mensaje_contenido_bien_tipo_editar"];
    ?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_bien_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<script>
function eliminar_bien_tipo(id_bien_tipo) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Bien de Id:'+id_bien_tipo+'?',
        html: '<span style="color:red">¿Deseas eliminar el Bien Tipo de Id:</span><span style="color:green">'+id_bien_tipo+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'bienes_tipos_eliminar_validar.php?id_bien_tipo='+id_bien_tipo;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}      
</script>
</body>
</html>