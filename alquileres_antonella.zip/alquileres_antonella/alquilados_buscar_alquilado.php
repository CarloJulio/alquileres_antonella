<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables de sesiones
    if (!isset($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"])) {
        $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"] = "";
    }  
    if (!isset($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"])) {
        $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"] = "";
    }  
    if (!isset($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"])) {
         $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"] = "No";
    }  
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
	<!-- Caracteres en español -->
    <meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Buscar Alquilado</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
	<div class="contenedor">
	  <h3><font class="font1">Alquilados</font></h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="menu_alquilados.php">Volver</a>
      <div class="contenedor texto-centrado">
		<h3><font class="font1">Buscar Alquilado</font></h3>	
	  </div> <!-- class="contenedor card texto-centrado" -->	 
	  <div class="contenedor">
      <div style="overflow-x:auto">   
	  <form name="formulario_buscar_alquilado" method="POST" action="alquilados_buscar_alquilado_validar.php" onsubmit="validar_formulario_buscar_alquilado();return document.vf_returnValue">
        <table class="tab7" align="center">	      
            <tr>   
            <td>
                <label><b>Nro. Identidad</b></label>
           		<input class="input3" type="text" name="alquilados_buscar_alquilado_buscar_nro_identidad" placeholder="Ej.: 5446627" maxlength="15" autofocus value="<?php echo $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"] ?>">
			</td>
            </tr>
            <tr>   
            <td align = 'right'>
                <button class="boton"><b>Buscar</b></button>
	        </td>
            </tr>
            <tr>   
            <td>
                <a href="alquilados_buscar_alquilado_crear.php">Crear Alquilado</a>&nbsp&nbsp 
	        </td>
            </tr>
        </table>    
      </form>
      </div> <!-- <div style="overflow-x:auto"> -->	  
      <br/>
      </div>  <!-- class="contenedor card texto-izquierdo" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
        if ($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"] == "Si") { // Nro. de identidad no existe
            $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe"] = "No";
            $buscar_contribuyente_contrato_crear_no_existe=$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_no_existe_mensaje"];
    ?>        
            <script>
                Swal.fire({
                    title: 'Mensaje',
                    text: '<?php echo $buscar_contribuyente_contrato_crear_no_existe ?>',
                    html: '<span style="color:red"><?php echo $buscar_contribuyente_contrato_crear_no_existe ?></span>',
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false
                });     
            </script>
    <?php        
        }    
	?>
    <?php
    // Mensaje de datos guardados 
    if($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"] == "Si"){
        $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"] = "No";
        $mensaje_alquilado_crear_contenido = $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje_contenido"];
    ?>
        <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Actualizados con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_alquilado_crear_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
        </script>
    <?php
    }
    ?>
    <script>
    // Validar formulario buscar alquilado con javascript
    function validar_formulario_buscar_alquilado() { 
        var errors="";
        var nro_indentidad = document.forms['formulario_buscar_alquilado'].elements['alquilados_buscar_alquilado_buscar_nro_identidad'].value; 
        if (nro_indentidad == "") {
            errors += '<font style="color:red">El Nro. de identidad <br/> no debe estar vacio</font>';
        } 
        // El nro_indentidad no es nulo
        if (errors == "") {
            // Chequear si el nro_indentidad es un número 
            var es_numero_nro_indentidad = parseInt(nro_indentidad);
            if(isNaN(es_numero_nro_indentidad)) {
                errors += '<font style="color:red">El Nro. de identidad <br/> debe ser un número</font>';
            } else {
                // Chequear si el nro_indentidad es un número entero
                nro_indentidad = parseFloat(nro_indentidad);
                if(Number.isInteger(nro_indentidad)){
                    // errors == "", no hace nada    
                } else {
                    errors += '<font style="color:red">El Nro. de identidad <br/> debe ser un número entero</font>';
                }
            }
        } 
        // Mensaje SweetAlert si errors diferente a ""
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.vf_returnValue = (errors == '');
    }
    </script>
</body>
</html>