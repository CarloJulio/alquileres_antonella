<?php
	 // Conexión a la base de datos Alquileres Antonella
	 require("conexion/conexion.php");
	 // Iniciar sesión del Usuario
	 session_start();
	 // Chequear si la sesión de usuario esta cerrado
	 if (!isset($_SESSION["usuario_usuario"])){
		header("Location:error1.php");
		exit();
	 } 
	 // Chequear si la sesión de usuario está vacio
	 if (empty($_SESSION["usuario_usuario"])){
		 header("Location:error1.php");
		 exit();
	 }
    // Fecha desde
	if (isset($_POST["recibos_fecha_1"])) {
       $fecha_rep_1 = $_POST["recibos_fecha_1"];
       $_SESSION['recibos_fecha_1'] = $_POST["recibos_fecha_1"];
    } else {
		$fecha_rep_1 = $_SESSION['recibos_fecha_1']; 
    }
	$fecha_rep_1=trim($fecha_rep_1);
	$fecha_rep_1i_valores = explode('/', $fecha_rep_1);
	$fecha_rep_1i = "$fecha_rep_1i_valores[2]-$fecha_rep_1i_valores[1]-$fecha_rep_1i_valores[0]";
	// Fecha hasta
	if (isset($_POST["recibos_fecha_2"])) {
       $fecha_rep_2 = $_POST["recibos_fecha_2"];
       $_SESSION['recibos_fecha_2'] = $_POST["recibos_fecha_2"];
    } else {
		$fecha_rep_2 = $_SESSION['recibos_fecha_2']; 
    }
	$fecha_rep_2=trim($fecha_rep_2);
	$fecha_rep_2i_valores = explode('/', $fecha_rep_2);
	$fecha_rep_2i = "$fecha_rep_2i_valores[2]-$fecha_rep_2i_valores[1]-$fecha_rep_2i_valores[0]";
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>mini Rentas - Recibos Lista - Fechas</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
    <script>
      function printe(){
        //desaparece el boton
        document.getElementById("menu").style.display='none';
        document.getElementById("volver").style.display='none';
        document.getElementById("volver2").style.display='none';
        document.getElementById("Imprimir").style.display='none';
        //se imprime la pagina
        window.print();
        //reaparece el boton
        document.getElementById("menu").style.display='inline';
        document.getElementById("volver").style.display='inline';
        document.getElementById("volver2").style.display='inline';
        document.getElementById("Imprimir").style.display='inline';
      }
    </script>
</head>
<body>
<?php
	// Recibos entre dos fechas
	$sql = "SELECT id_recibo, id_alquiler, descripcion, anulado, fecha_recibo_reg, monto ";
	$sql .= "FROM tab_recibos WHERE(DATE_FORMAT(fecha_recibo_reg, '%Y-%m-%d') BETWEEN '$fecha_rep_1i' AND '$fecha_rep_2i') "; 
	$sql .= "ORDER BY id_recibo ASC";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
	// Cuentas recibos
	$sql7 = "SELECT count(id_recibo) as nro_recibos ";
	$sql7 .= "FROM tab_recibos WHERE (DATE_FORMAT( fecha_recibo_reg, '%Y-%m-%d') "; 
	$sql7 .= "BETWEEN '$fecha_rep_1i' AND '$fecha_rep_2i')";
	$query7 = $mysqli->query($sql7);
	$row7 = $query7->fetch_assoc();
	$nro_registros_7 = $query7->num_rows;
	if($nro_registros_7!=0) {
		$total_recibos_nro_recibos = $row7['nro_recibos'];
	} else {
		$total_recibos_nro_recibos = 0;
	}
?>
<div class="contenedor-2">
   	<?php
		if($nro_registros!=0) {
	?>
	<div style="overflow-x:auto">
		<a id="volver2" href="recibos_fechas.php"><font class="font7">Volver</font></a>
		<table class="tab12">
			<tr class="tr13">
				<td style="width:25%"><img src='imagen/antonella.png' alt='logo at' width='280px' height='50px'></td>
				<td>
					Listado Detallado de Recibos 
					<br/>
					Fecha (desde):<?php echo $fecha_rep_1 ?>
					&nbsp
					Fecha (hasta):<?php echo $fecha_rep_2 ?>
				</td>
			<tr>
		</table>
		<table class="tab12">
  			<thead>
				<tr class="tr12">
	  				<th style="width:8%">Recib.</th>
	  				<th style="width:10%">Fecha</th>
	  				<th style="width:20%">Nombre</th>
      				<th style="width:40%">Bien</th>
      				<th style="width:10%">Monto</th>
      				<th>Enlace</th>
      			</tr>
  			</thead>
  			<tbody>
  		<?php	
  			$nro_recibo = 0;
			$total = 0;
			while ($row=$query->fetch_assoc()) { 
				// Sumar el monto de los recibos
				$total = $total + $row['monto'];
				// Sumar los recibos
				$nro_recibo = $nro_recibo + 1;
				// Buscar el alquilado y el bien del recibo
				$id_alquiler = $row['id_alquiler'];
				$sql8 = "SELECT id_alquiler, id_alquilado, id_bien FROM tab_alquileres ";
				$sql8 .=	"WHERE (id_alquiler = ".$id_alquiler.")";
				$query8 = $mysqli->query($sql8);
				$row8 = $query8->fetch_assoc();
				$nro_registros_8 = $query8->num_rows;
				if($nro_registros_8!=0) {
					$id_alquilado = $row8['id_alquilado'];
					$id_bien = $row8['id_bien'];
				} else {
					$id_alquilado = 0;
					$id_bien = 0;
				}

	    ?>
	    		<tr class="tr12">
    				<td>
    					<?php echo $row['id_recibo']; ?>
    				</td>
    				<td>
    				<?php 
    					$date = new DateTime($row['fecha_recibo_reg']);
              			echo $date->format('d-m-Y');
    				?>
    				</td>
    				<td>
					<?php 
						// Buscar nombre del alquilado del recibo
						$sql9 = "SELECT id_alquilado, nombre, apellido FROM tab_alquilados ";
						$sql9 .= "WHERE (id_alquilado = ".$id_alquilado.")";
						$query9 = $mysqli->query($sql9);
						$row9 = $query9->fetch_assoc();
						$nro_registros_9 = $query9->num_rows;
						if($nro_registros_9!=0) {
							$nombre = $row9['nombre']." ".$row9['apellido'];
						} else {
							$nombre = "???";
						}						
						echo $nombre; 
					?>
					</td>
        			<td>
					<?php 
						// Buscar bien alquilado del recibo
						$sql10 = "SELECT id_bien, bien, descripcion FROM tab_bienes ";
						$sql10 .= "WHERE (id_bien = ".$id_bien.")";
						$query10 = $mysqli->query($sql10);
						$row10 = $query10->fetch_assoc();
						$nro_registros_10 = $query10->num_rows;
						if($nro_registros_10!=0) {
							$bien = $row10['bien'].", ".$row10['descripcion'];
						} else {
							$bien = "???";
						}	
						if($row['anulado'] == "No") {	
							echo $bien; 
						} else {
							echo $bien." <span class='anulado2'><b>(Anulado)</b></span>"; 
						}		
					?>
					</td>
        			<td><div align="right"><?php echo number_format($row['monto'],2,',','.') ?></div></td>
					<td>
						<a href="recibos_fechas_lista_vista.php?id_recibo=<?php echo $row['id_recibo'];?>"><?php echo "Vista"; ?></a>	
					</td>
        		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
		</table>
		<table class="tab12">
			<tr class="tr13">
				<td>
					Total Recibos: <?php echo number_format($total_recibos_nro_recibos,0,',','.') ?>
					<br/>
					Total Monto: <?php echo number_format($total,2,',','.') ?>
				</td>
			<tr>
		</table>
		<span class="empresa">	
			Usuario: <?php echo $_SESSION["usuario_usuario"]; ?>
		<br/>
        <?php 
            // mini Sistemas cjcv
            require("mini.php"); 
        ?>
        </span>
        <br/>
        <br/>
		<a id="menu" href="menu.php"><font class="font7">Menú</font></a>&nbsp&nbsp
        <a id="volver" href="recibos_fechas.php"><font class="font7">Volver</font></a>&nbsp&nbsp
        <a id="Imprimir" href="#" onclick="printe()"><font class="font7">Imprimir</font></a> 
        <br/><br/>
	</div>	
	<?php
		}else{ // if(!empty($resultados))
			echo "<div>";
			echo'<a id="volver" href="recibos_fechas.php"><font class="font7">Volver</font></a>';
			echo "<br/><br/>";
			echo "<span style='color:red'><font class='font3'>No se encontró Recibos</font></span>";
			echo "</div>";
		} // if(!empty($resultados))
	?>	
</div> <!-- div class="contenedor" -->
</body>
</html>