<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Menú</title>
    <!-- Mi framework css -->
    <link href="css/miframework.css" rel="stylesheet">
    <!-- Menú vertical -->
    <link href="css/menu_vertical.css" rel="stylesheet">
    <!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
	<link rel="shortcut icon" href="imagen/avatar.png" />
</head>
<body>
	<div class="contenedor">
        <font class="font2">Id Usuario: <?php echo $_SESSION["id_usuario"]; ?></font><br/>
        <font class="font2">Usuario: <?php echo $_SESSION["usuario_usuario"]; ?></font><br/>
        <font class="font2">Rol: <?php echo $_SESSION["usuario_rol"]; ?></font>
       	<h3><font class="font2">Alquileres Antonella</font></h3> 
    </div>    
    <div class="contenedor">
      <!-- Menú principal -->    
      <div class="menu">
        <ul>
            <li class="enlace2"><span style="color:yellow">Menú Principal</span></li>
            <li class="enlace1"><a href="menu_alquilados.php">Alquilados</a></li>
            <li class="enlace1"><a href="menu_bienes.php">Bienes</a></li>
            <?php
                if ($_SESSION["usuario_rol"] == "Administrador") {
            ?>
                <li class="enlace1"><a href="usuarios.php">Usuarios</a></li>
            <?php
                }
            ?>
            <li class="enlace1"><a href="acerca.php">Acerca</a></li>
            <li class="enlace3" onclick="cerrar_sistema()"><a><span style="color:red">Cerrar</span></a></li>
        </ul>   
      </div>
    </div>
    <div class="contenedor texto-left">
        <span class="empresa">
            <?php 
                // mini Sistemas cjcv
                require("mini.php"); 
            ?>
        </span>
    </div> <!-- class="contenedor card texto-centrado" -->   
    <script>
    // Cerrar Sistema
    function cerrar_sistema() {
        Swal.fire({
            title: 'Mensaje',
            text: '¿Confirma en Cerrar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = 'cerrando.php';
            } else {
                // Dijeron que no
            }
        });
    }
</script>
</body>
</html>