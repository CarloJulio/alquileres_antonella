<?php
	// Conectar a la base de datos Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Usuario cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Datos del bien tipo
	$id_bien_tipo = $_SESSION["id_bien_tipo_editar"];
	$bien_tipo = $_SESSION["bien_tipo_editar"];
	$bien_usuario = $_SESSION["usuario_usuario"];
	// Actualizar datos del Bien Tipo
	$sql2 = "UPDATE tab_bienes_tipos SET bien_tipo='$bien_tipo',usuario='$bien_usuario',fecha_usuario_reg=Current_Timestamp WHERE id_bien_tipo='$id_bien_tipo'";
	$query2=$mysqli->query($sql2);
	$_SESSION["mensaje_bien_tipo_editar"] = "Si";
	$_SESSION["mensaje_contenido_bien_tipo_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'bienes_tipos.php'</script>";
?>