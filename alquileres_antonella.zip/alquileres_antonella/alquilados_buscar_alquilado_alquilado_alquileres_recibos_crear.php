<?php
    // Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    // Iniciar sesión del Usuario
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Iniciar variables se sesiones
    if (!isset($_SESSION["recibo_crear_s_guardar"])){
        $_SESSION["recibo_crear_s_guardar"] = "No";
    }
    if (!isset($_SESSION["recibo_descripcion_crear"])){
        $_SESSION["recibo_descripcion_crear"] = "";
    }
    if (!isset($_SESSION["recibo_monto_crear"])){
        $_SESSION["recibo_monto_crear"] = $_SESSION["alquiler_monto"];
    }
    if (!isset($_SESSION["recibo_fecha_crear"])){
        $_SESSION["recibo_fecha_crear"] = "";
        // Hora y fecha actual
        $sql = "SELECT current_date";
        $row = $mysqli->query($sql);
        $consultaf = $row->fetch_assoc();
        $fechadelmysql = date_create($consultaf['current_date']);
        $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
        $_SESSION['fecha_hoy'] = $fechadelmysql;
        $_SESSION["recibo_fecha_crear"] = $_SESSION['fecha_hoy'];
        // Pasar fecha a formato de - a /
        $fecha_recibo = $_SESSION["recibo_fecha_crear"];
        $fecha_recibo = trim($fecha_recibo);
        $fecha_recibo_li_valores = explode('-', $fecha_recibo);
        $fecha_recibo_1i = "$fecha_recibo_li_valores[0]/$fecha_recibo_li_valores[1]/$fecha_recibo_li_valores[2]";
        $_SESSION["recibo_fecha_crear"] = $fecha_recibo_1i;
    }
    // Datos del Alquiler
    $id_alquiler = $_SESSION["id_alquiler"];
    $bien = $_SESSION["bien"];
    $alquiler_descripcion = $_SESSION["alquiler_descripcion"];
    $alquiler_monto = $_SESSION["alquiler_monto"];
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable a diferentes tamaños de pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Recibos - Crear</title>
    <link rel="shortcut icon" href="imagen/avatar.png" />
    <!-- Datepicker -->
    <link rel="stylesheet" href="css/datepicker.css">
    <script src="js/datepicker-1.js"></script>
    <script src="js/datepicker.js"></script>
    <!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- Mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <!-- Función calendario -->     
    <script>
        $( function() {
            $( "#datepicker" ).datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        });
    </script>
</head>
<body>
	<div class="contenedor">
	  <h3>
        <font class="font1">Recibos - Crear</font>
      </h3>	
	  <a href="menu.php">Menú</a>&nbsp&nbsp
      <a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=<?php echo $id_alquiler ?>">Volver</a>
      <br/><br/>
      <font class="font2">Id Alquiler: <?php echo $id_alquiler; ?></font><br/>
      <font class="font2">Bien: <?php echo $bien; ?></font><br/>
      <font class="font2">Descripción: <?php echo $alquiler_descripcion; ?></font><br/>
      <font class="font2">Monto: <?php echo $alquiler_monto; ?></font><br/>
      <br/><br/>
      <div class="contenedor">
		<div class="contenedor texto-centrado">
			<h3><font class="font1">Crear Recibo</font></h3>	
		</div> <!-- class="contenedor card texto-centrado" -->	 
		<div style="overflow-x:auto"> 
		<form name="formulario_recibo" method="POST" action="alquilados_buscar_alquilado_alquilado_alquileres_recibos_crear_validar_1.php" onsubmit="validar_formulario_recibo();return document.MM_returnValue">
            <table class="tab6" align="center">	
                <td>    
                    <label><b>Descripción</b></label>
                    <input class="input" type="text" name="recibo_descripcion_crear" maxlength="255" autofocus value="<?php echo $_SESSION["recibo_descripcion_crear"] ?>">
                </td>
                </tr>
                <tr>   
                <td>     
                    <label><b>Fecha</b></label>
                    <input class="input" type="text" name="recibo_fecha_crear" id="datepicker" class="datepicker" maxlength="10" readonly value="<?php echo $_SESSION["recibo_fecha_crear"] ?>"/>
                </td>
                </tr>
                <tr>   
                <td>    
                    <label><b>Monto</b></label>
                    <input class="input" type="text" name="recibo_monto_crear" maxlength="15" value="<?php echo $_SESSION["recibo_monto_crear"] ?>">
                </td>
                </tr>
                <tr>   
                <tr>   
                <td>    
                    <input class="boton" type="submit" value="Guardar">
                </td>
                </tr>
            </table>
        </form>
        <br/>
        </div> <!-- <div style="overflow-x:auto"> -->	
	  </div> <!-- class="contenedor-usuario" -->
	  <div class="contenedor texto-centrado">
	  	<span class="empresa">
		<?php 
			// mini Sistemas cjcv
			require("mini.php"); 
		?>
		</span>
	   </div> <!-- class="contenedor card texto-centrado" -->	 
	</div> <!-- class="contenedor" -->
	<?php
    $recibo_crear_s_guardar = $_SESSION["recibo_crear_s_guardar"];
    if($recibo_crear_s_guardar == "Si") {
        $_SESSION["recibo_crear_s_guardar"] = "No";
    ?>
    <script>
        Swal.fire({
            title: 'Mensaje',
            text: '¿Deseas Guardar?',
            showCancelButton: true,
            confirmButtonText: 'Si',
            cancelButtonText: 'Cancelar',
            allowOutsideClick: false
        })
        .then(resultado => {
            if (resultado.value) {
                // Hicieron click en 'Sí'
                location.href = "alquilados_buscar_alquilado_alquilado_alquileres_recibos_crear_validar_2.php";
            } else {
                // Hicieron click en 'Cancelar'
            }
        });
    </script>
    <?php
        }
    ?>
    <script>
    // Validar formulario bien con javascript
    function validar_formulario_recibo() { 
        var errors="";
        var valor_vacio = document.forms['formulario_recibo'].elements['recibo_descripcion_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">La Descripción no debe estar vacio</font>';
        } 
        var valor_vacio = document.forms['formulario_recibo'].elements['recibo_monto_crear'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">El Monto no debe estar vacio</font>';
        } 
        var monto = document.forms['formulario_recibo'].elements['recibo_monto_crear'].value;
        // Chequea si el monto es un número
        if(errors == "" && isNaN(monto)) {
            errors += '<font style="color:red">El Monto debe ser un número</font>';    
        }
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.MM_returnValue = (errors == '');
    }
    </script>    
</body>
</html>