<?php
    // Iniciar sesión del Usuario
    session_start();
    // Inicializar las variables de sesiones
    if (!isset($_SESSION["usuario_usuario"])) {
        $_SESSION["usuario_usuario"] = "";
    }  
    if (!isset($_SESSION["usuario_password"])) {
        $_SESSION["usuario_password"] = "";
    }  
    if (!isset($_SESSION["usuario_incorrecto"])) {
        $_SESSION["usuario_incorrecto"] = "";
    }  
    $usuario_usuario = $_SESSION["usuario_usuario"];
    $usuario_password = $_SESSION["usuario_password"];
?>   
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
    <!-- Caracteres en español -->
	<meta charset="UTF-8">
    <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Mi framework css -->
    <link rel="stylesheet" href="css/miframework.css">
	<!-- mensajes Sweetalert -->
    <link href="css/sweetalert2.min.css" rel="stylesheet">
    <script src="js/sweetalert2.all.min.js"></script>
    <title>Alquileres Antonella - Iniciar Usuario</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
</head>
<body>
	<div class="contenedor">
		<div class="contenedor cuadro2 texto-centrado">
		    <h3><font class="font1"><span class="lema1">Alquileres </span><span class="lema2">Antonella</span></font>
                <br/>
                <font class="font2">Iniciar Usuario</font>
            </h3>	
			<form name="formulario_usuario" method="POST" action="usuario_validar.php" onsubmit="formulario_usuario_validar();return document.return_value">
            <form method="POST" action="index.php">
				<input class="input2" type="text" name="usuario_usuario" placeholder="Usuario" maxlength="20" autofocus value="<?php echo $usuario_usuario; ?>">
				<br/>
                <input class="input2" type="password" name="usuario_password" maxlength="20" placeholder="Contraseña" value="<?php echo $usuario_password; ?>">
				<br/>
                <button class="boton"><b>Iniciar</b></button>
			</form>
			<span class="empresa">
				<?php 
  					// mini Sistemas cjcv
  					require("mini.php"); 
				?>
			</span>
		</div>  <!-- class="contenedor card texto-centrado" -->
	</div> <!-- class="contenedor" -->
	<script>
    // Validar formulario con javascript
    function formulario_usuario_validar() { 
        var errors="";
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_usuario'].value; 
        if (valor_vacio == "") {
            errors += '<font style="color:red">Debes escribir El Usuario</font>';
        } 
        var valor_vacio = document.forms['formulario_usuario'].elements['usuario_password'].value;
        if (errors == "" && valor_vacio == "") {
            errors += '<font style="color:red">Debes escribir La Contraseña</font>';
        } 
        if (errors) {
            Swal.fire({
                title: 'Mensaje',
                text: errors,
                html: errors,
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false
            });     
        }       
        document.return_value = (errors == '');
    }
    </script>
    <?php    
        if ($_SESSION["usuario_incorrecto"]=="Si") { // Usuario o contraseña incorrecta
            $_SESSION["usuario_incorrecto"]="No";
            $usuario_incorrecto_mensaje=$_SESSION["usuario_incorrecto_mensaje"];
    ?>    
            <script>
                 Swal.fire({
                        title: 'Mensaje',
                        text: '<?php echo $usuario_incorrecto_mensaje ?>',
                        html: '<span style="color:red"><?php echo $usuario_incorrecto_mensaje ?></span>',
                        confirmButtonText: 'Aceptar',
                        allowOutsideClick: false
                    });
            </script>
    <?php
        }
    ?>
</body>
</html>