<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Se presionó el botón guardar
	if (isset($_POST["bien_bien_crear"])) {
		$_SESSION["bien_bien_crear"] = trim($_POST["bien_bien_crear"]);
		$_SESSION["bien_descripcion_crear"] = $_POST["bien_descripcion_crear"];
		$_SESSION["bien_direccion_crear"]= $_POST["bien_direccion_crear"];
		$_SESSION["bien_fecha_crear"] = $_POST["bien_fecha_crear"];
		// Mensaje si desea guardar datos
		$_SESSION["bien_crear_s_guardar"] = "Si";
		echo "<script>location.href = 'bienes_crear.php'</script>";
	}
?>