<?php
	// Conexión a la base de datos Alquileres Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
	// Datos del Bien Tipo
	$bien_tipo = $_SESSION["bien_tipo_crear"];
	$bien_tipo_usuario = $_SESSION["usuario_usuario"];
	// Guardar nuevo Bien Tipo	
	$sql="INSERT INTO tab_bienes_tipos (bien_tipo, usuario, fecha_usuario_reg) ";
	$sql.="VALUES ('$bien_tipo','$bien_tipo_usuario',Current_Timestamp)";
    $query=$mysqli->query($sql);
    /* Destruir las variables la variables de sesiones
    de los datos del Bien Tipo nuevo */ 
    unset($_SESSION["bien_tipo_crear"]);
    // Mensaje de dato guardado
    $_SESSION["mensaje_bien_tipo_editar"] = "Si";
	$_SESSION["mensaje_contenido_bien_tipo_editar"] = "Datos Guardado con Éxito.";
	echo "<script>location.href = 'bienes_tipos.php'</script>";
?>