<?php
	// Conexión a la base de datos Alquileres Antonella
    require("conexion/conexion.php");
    session_start();
    // Chequear si la sesión de usuario esta cerrado
    if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Usuario
    $alquilado_usuario = $_SESSION["usuario_usuario"];
	// Guardar datos
	$nro_idedntidad_crear = $_SESSION["alquilados_buscar_alquilado_crear_nro_identidad"];
	$alquilados_buscar_alquilado_crear_nombre = $_SESSION["alquilados_buscar_alquilado_crear_nombre"];
	$alquilados_buscar_alquilado_crear_apellido = $_SESSION["alquilados_buscar_alquilado_crear_apellido"];
	$sql="INSERT INTO tab_alquilados (nro_identidad, nombre, apellido, usuario, fecha_usuario_reg) ";
	$sql.="VALUES ('$nro_idedntidad_crear','$alquilados_buscar_alquilado_crear_nombre','$alquilados_buscar_alquilado_crear_apellido','$alquilado_usuario',Current_Timestamp)";
    $query=$mysqli->query($sql);
    // Asignar valor a la varible de sesión
    $_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad"] = $_SESSION["alquilados_buscar_alquilado_crear_nro_identidad"];
    // Borrar variables de sesiones
	unset($_SESSION["alquilados_buscar_alquilado_crear_nro_identidad"]);
	unset($_SESSION["alquilados_buscar_alquilado_crear_nombre"]);
	unset($_SESSION["alquilados_buscar_alquilado_crear_apellido"]);
	// Mensaje datos guardados
	$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"] = "Si";
	$_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje_contenido"] = "Datos Guardado con Éxito.";
	if($_SESSION["alquilados_buscar_alquilado_buscar_nro_identidad_mensaje"] == "Si") {
		echo "<script>location.href = 'alquilados_buscar_alquilado.php'</script>";
		exit();	
	}
?>