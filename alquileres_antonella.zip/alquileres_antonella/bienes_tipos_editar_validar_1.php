<?php
    // Conectar a la base de datos Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    } 
	// Chequear si la sesión de usuario está vacio
	if (empty($_SESSION["usuario_usuario"])){
		header("Location:error1.php");
		exit();
	}
    // Si presionó el botón guardar
	if (isset($_POST["bien_tipo_editar"])) {
		$_SESSION["bien_tipo_editar"] = trim($_POST["bien_tipo_editar"]);
		// Validación formulario bien correcta
		$_SESSION["bien_tipo_editar_s_guardar"] = "Si";
		echo "<script>location.href = 'bienes_tipos_editar.php'</script>";
	}
?>