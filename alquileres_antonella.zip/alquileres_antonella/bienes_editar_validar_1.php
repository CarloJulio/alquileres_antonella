<?php
    // Conectar a la base de datos Antonella
	require("conexion/conexion.php");
	// Iniciar sesión del Usuario
	session_start();
	// Chequear si la sesión de usuario esta cerrado
	if (!isset($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    } 
    // Chequear si la sesión de usuario está vacio
    if (empty($_SESSION["usuario_usuario"])){
        header("Location:error1.php");
        exit();
    }
    // Validar formulario bien con php
	$id_bien = $_SESSION["id_bien_editar_bienes"];
	// Si presionó el botón guardar
	if (isset($_POST["bien_bien_editar"])) {
		$_SESSION["bien_bien_editar"] = trim($_POST["bien_bien_editar"]);
		$_SESSION["bien_descripcion_editar"] = $_POST["bien_descripcion_editar"];
		$_SESSION["bien_direccion_editar"] = $_POST["bien_direccion_editar"];
		$_SESSION["bien_fecha_editar"] = $_POST["bien_fecha_editar"];
		// Validación formulario bien correcta
		$_SESSION["bien_editar_s_guardar"] = "Si";
		echo "<script>location.href = 'bienes_editar.php'</script>";
	}
?>