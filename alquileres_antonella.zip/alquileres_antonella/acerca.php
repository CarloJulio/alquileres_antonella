<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  } 
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  if (!isset($_SESSION["mensaje_usuario_editar"])){
      $_SESSION["mensaje_usuario_editar"] = "";
  } 
  // Iniciar variables de sesiones
  if (!isset($_SESSION["usuario_editar_s_error"])){
    $_SESSION["usuario_editar_s_error"] = "";  
  } 
  if (!isset($_SESSION["usuario_editar_error_mensaje"])){
    $_SESSION["usuario_editar_error_mensaje"] = "";  
  } 
?>
<!DOCTYPE html><!-- Documento HTML5 -->
<html lang="es"><!-- Formato español -->
<head>
  <!-- Caracteres en español -->
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Acerca</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
	$sql = "SELECT id_usuario, usuario, clave, rol ";
	$sql .= "FROM tab_usuarios ";
	$sql .= "ORDER BY id_usuario ASC ";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Acerca</font>
  </h3>	
  <a href="menu.php">Menu</a>&nbsp&nbsp
  <div>
    <br/> 
    Aquileres Antonella es una oficina que <br/> 
    alquila bienes a las personas como: <br/> 
    casas, kioscos, garages y otros bienes.
  </div> <!-- <div> -->	
  <br/> 
 <span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
</span>
</div> <!-- div class="contenedor" -->
</body>
</html>