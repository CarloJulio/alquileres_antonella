<?php
	// Conexión a la base de datos Alquileres Antonella
  require("conexion/conexion.php");
  // Iniciar sesión del Usuario
  session_start();
	// Chequear si la sesión de usuario esta cerrado
  if (!isset($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  // Chequear si la sesión de usuario está vacio
  if (empty($_SESSION["usuario_usuario"])){
      header("Location:error1.php");
      exit();
  }
  if (isset($_GET["id_alquilado"])) {
      $id_alquilado = $_GET["id_alquilado"];
  }else{
      echo "No se encuentra el id_alquilado del Alquilado";
      exit();
  }
  // Eliminar variable se sesión del formulario editar alquiler
  unset($_SESSION["alquiler_bien_editar"]);
  unset($_SESSION["alquiler_descripcion_editar"]);
  unset($_SESSION["alquiler_fecha_editar"]);
  unset($_SESSION["alquiler_monto_editar"]);
  // Iniciar variables
  if (!isset($_SESSION["id_alquilado"])){
      $_SESSION["id_alquilado"] = "";
  } 
  if (!isset($_SESSION["alquilado_nombre"])){
      $_SESSION["alquilado_nombre"] = "";
  } 
  if (!isset($_SESSION["alquilado_apellido"])){
      $_SESSION["alquilado_apellido"] = "";
  } 
  // Mensaje de dato guardado
  if (!isset($_SESSION["mensaje_alquiler_editar"])){
      $_SESSION["mensaje_alquiler_editar"] = "";
  } 
  if (!isset($_SESSION["mensaje_contenido_alquiler_editar"])){
      $_SESSION["mensaje_contenido_alquiler_editar"] = "";
  } 
  // Mensaje de error
  if (!isset($_SESSION["mensaje_alquiler_error_editar"])){
    $_SESSION["mensaje_alquiler_error_editar"] = "";
  } 
  // fecha actual, formato español
  $sql = "SELECT current_date";
  $row = $mysqli->query($sql);
  $consultaf = $row->fetch_assoc();
  $fechadelmysql = date_create($consultaf['current_date']);
  $fechadelmysql = date_format($fechadelmysql, 'd-m-Y');
  $_SESSION["fecha_hoy"] = $fechadelmysql;
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
  <!-- Adaptable para varias pantallas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Alquileres Antonella - Alquileres</title>
	<link rel="shortcut icon" href="imagen/avatar.png" />
	<!-- Mi framework css -->
  <link rel="stylesheet" href="css/miframework.css">
  <!-- Mensajes Sweetalert -->
  <link href="css/sweetalert2.min.css" rel="stylesheet">
  <script src="js/sweetalert2.all.min.js"></script>
</head>
<body>
<?php
  $sql2 = "SELECT id_alquilado, nro_identidad, nombre, apellido ";
  $sql2 .= "FROM tab_alquilados WHERE (id_alquilado = $id_alquilado)";
  $query2 = $mysqli->query($sql2);
  $nro_registros2 = $query2->num_rows;
  if($nro_registros2!=0) {
    $row2=$query2->fetch_assoc();
    $nro_identidad = $row2['nro_identidad'];
    $alquilado_nombre = $row2['nombre'];
    $alquilado_apellido = $row2['apellido'];
    $_SESSION["id_alquilado"] = $row2['id_alquilado'];
    $_SESSION["alquilado_nro_identidad"] = $row2['nro_identidad'];
    $_SESSION["alquilado_nombre"] = $row2['nombre'];
    $_SESSION["alquilado_apellido"] = $row2['apellido'];
  } else {
    echo "No se encuentra el id_alquilado del Alquilado (tabla)";
    exit(); 
  }  
	$sql = "SELECT id_alquiler, id_bien, descripcion, fecha_alquiler_reg, monto ";
  $sql .= "FROM tab_alquileres WHERE (id_alquilado = $id_alquilado) ORDER BY id_alquiler";
	$query = $mysqli->query($sql);
	$nro_registros = $query->num_rows;
?>
<div class="contenedor">
  <h3>
  	<font class="font1">Alquilados</font>
  </h3>	
  <a href="menu.php">Menú</a>&nbsp&nbsp
  <a href="alquilados_buscar_alquilado_alquilado.php?nro_identidad=<?php echo $nro_identidad ?>">Volver</a>
  <br/><br/>
  <font class="font2">Id Alquilado: <?php echo $id_alquilado; ?></font><br/>
  <font class="font2">Nro. Identidad: <?php echo $nro_identidad; ?></font><br/>
  <font class="font2">Nombre: <?php echo $alquilado_nombre; ?></font><br/>
  <font class="font2">Apellido: <?php echo $alquilado_apellido; ?></font><br/>
  <div class="contenedor texto-centrado">
  	<h3><font class="font1">Alquileres</font></h3>	
  </div> <!-- class="contenedor card texto-centrado" -->
 	<div style="overflow-x:auto">
    <table class="tab4" align="center">
         <thead>
        <tr class="tr4">
          <td>
            <a href="alquilados_buscar_alquilado_alquilado_alquileres_crear.php">Crear</a>&nbsp&nbsp  
          </td>
        </tr>  
        <?php
        if($nro_registros!=0) {
        ?>
       	<tr class="tr4">
	  				<th style="width:5%">Id</th>
            <th style="width:30%">Bien</th>
	  				<th style="width:30%">Descripción</th>
            <th style="width:8%">Fecha</th>
            <th style="width:10%">Monto</th>
      			<th >Enlace</th>
				</tr>
  			</thead>
  			<tbody>
  		<?php	
			while ($row=$query->fetch_assoc()) { 
          // Pasar fecha a formato español
          $fecha_bien = $row['fecha_alquiler_reg'];
          $fecha_bien = trim($fecha_bien);
          $fecha_bien_li_valores = explode('-', $fecha_bien);
          $fecha_bien_1i = "$fecha_bien_li_valores[2]/$fecha_bien_li_valores[1]/$fecha_bien_li_valores[0]";
          // Buscar bien
          $id_bien = $row['id_bien'];
          $sql3 = "SELECT id_bien, bien, descripcion FROM tab_bienes WHERE (id_bien = $id_bien)";
          $query3 = $mysqli->query($sql3);
          $nro_registros3 = $query3->num_rows;
          // Si existe el bien
          if($nro_registros3!=0) {
             $row3=$query3->fetch_assoc();
             $bien_descripcion = $row3['bien']." - ".$row3['descripcion'];
          } else {
             $bien_descripcion = "???";
          }      
      ?>
	    		<tr class="tr4">
    				<td align = "center"><?php echo $row['id_alquiler']; ?></td>
    				<td><?php echo $bien_descripcion; ?></td>
            <td><?php echo $row['descripcion']; ?></td>
        		<td align = 'center'><?php echo $fecha_bien_1i ?></td>
            <td align = 'right'><?php echo number_format($row['monto'],2,',','.'); ?></td>
        		<td>
        				<a href="alquilados_buscar_alquilado_alquilado_alquileres_recibos.php?id_alquiler=<?php echo $row['id_alquiler']?>">Recibos</a>
                <a href="alquilados_buscar_alquilado_alquilado_alquileres_vista.php?id_alquiler=<?php echo $row['id_alquiler']?>">Vista</a>
                <a href="alquilados_buscar_alquilado_alquilado_alquileres_editar.php?id_alquiler=<?php echo $row['id_alquiler']?>">Editar</a>
                <a href="#" onclick="eliminar_alquiler(<?php echo $row['id_alquiler']?>)">Eliminar</a>
            </td> 
	    		</tr>
    	<?php
			} // while ($row=$query->fetch_assoc())
		?>
  			</tbody>
        <?php
        } else { // if($nro_registros!=0)
          echo "<tr class='tr2'>";
          echo "<td align = 'center'>";
          echo "<div align='center'>";
          echo "<span style='color:red'><font class='font3'>No se encontró Alquileres</font></span>";
          echo "</div>";
          echo "</td>";
          echo "</tr>";
        } // if($nro_registros!=0)
  ?>  
		</table>
	</div> <!-- <div style="overflow-x:auto"> -->	
  <div class="contenedor texto-centrado">
 	<span class="empresa">
	<?php 
		// mini Sistemas cjcv
		require("mini.php"); 
	?>
	</span>
  </div> <!-- class="contenedor card texto-centrado" -->	 
</div> <!-- div class="contenedor" -->
<?php
    // Mensaje de datos guardados 
    if($_SESSION["mensaje_alquiler_editar"] == "Si"){
        $_SESSION["mensaje_alquiler_editar"]="No";
        $mensaje_alquiler_contenido = $_SESSION["mensaje_contenido_alquiler_editar"];
    ?>
    <script> 
        swal.fire({ title: 'Mensaje',
            text: 'Datos Guardado con Éxito.',
            html: '<span style="color:green"><?php echo $mensaje_alquiler_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    </script>
<?php
    }
?>
<?php
  	// Mensaje de error 
  	if($_SESSION["mensaje_alquiler_error_editar"]=="Si") {
        $_SESSION["mensaje_alquiler_error_editar"]="No";
        $mensaje_alquiler_contenido = $_SESSION["mensaje_contenido_alquiler_editar"];
?>
  		<script> 
        swal.fire({ title: 'Mensaje',
            text: 'No se pudo eliminar.',
            html: '<span style="color:red"><?php echo $mensaje_alquiler_contenido ?></span>',
            timer: 3000,
            showConfirmButton: true,
            confirmButtonText: 'Aceptar',
            timerProgressBar:true,
            allowOutsideClick: false
        });
    	</script>
<?php
    }
?> 	
<script>
function eliminar_alquiler(id_alquiler) {
  Swal.fire({
        title: 'Mensaje',
        text: '¿Deseas eliminar el Alquiler de Id:'+id_alquiler+'?',
        html: '<span style="color:red">¿Deseas eliminar el Alquiler de Id:</span><span style="color:green">'+id_alquiler+'</span></span><span style="color:red">?</span></span>',
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'Cancelar',
        allowOutsideClick: false
    })
    .then(resultado => {
        if (resultado.value) {
           // Hicieron click en 'Sí'
           location.href = 'alquilados_buscar_alquilado_alquilado_alquileres_eliminar_validar.php?id_alquiler='+id_alquiler;
        } else {
           // Hicieron click en 'Cancelar'
        }
    });
}      
</script>
</body>
</html>